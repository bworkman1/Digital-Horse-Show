<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-27 00:29:20 --> Severity: Notice --> Undefined index: latitude C:\MAMP\htdocs\horse\application\controllers\Login.php 50
ERROR - 2016-03-27 00:29:20 --> Severity: Notice --> Undefined index: longitude C:\MAMP\htdocs\horse\application\controllers\Login.php 51
ERROR - 2016-03-27 00:29:21 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 00:29:21 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 00:29:21 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 00:29:21 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 23
ERROR - 2016-03-27 00:29:48 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 00:29:48 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 00:29:48 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 00:29:48 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 23
ERROR - 2016-03-27 00:30:34 --> Severity: Notice --> Undefined index: latitude C:\MAMP\htdocs\horse\application\controllers\Login.php 50
ERROR - 2016-03-27 00:30:34 --> Severity: Notice --> Undefined index: longitude C:\MAMP\htdocs\horse\application\controllers\Login.php 51
ERROR - 2016-03-27 00:32:53 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 00:32:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 00:34:17 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 00:34:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 00:35:49 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 00:35:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 00:44:31 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 00:44:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 00:45:16 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 00:45:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 00:54:21 --> Severity: error --> Exception: Call to undefined method MY_Loader::modal() C:\MAMP\htdocs\horse\application\controllers\Test_scripts.php 37
ERROR - 2016-03-27 00:54:30 --> Severity: Warning --> Missing argument 1 for Create_users::__construct(), called in C:\MAMP\htdocs\horse\system\core\Loader.php on line 353 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 14
ERROR - 2016-03-27 00:54:30 --> Severity: Warning --> Missing argument 2 for Create_users::__construct(), called in C:\MAMP\htdocs\horse\system\core\Loader.php on line 353 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 14
ERROR - 2016-03-27 00:54:30 --> Severity: Warning --> Missing argument 3 for Create_users::__construct(), called in C:\MAMP\htdocs\horse\system\core\Loader.php on line 353 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 14
ERROR - 2016-03-27 00:54:30 --> Severity: Warning --> Missing argument 4 for Create_users::__construct(), called in C:\MAMP\htdocs\horse\system\core\Loader.php on line 353 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 14
ERROR - 2016-03-27 00:54:30 --> Severity: Warning --> Missing argument 5 for Create_users::__construct(), called in C:\MAMP\htdocs\horse\system\core\Loader.php on line 353 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 14
ERROR - 2016-03-27 00:54:30 --> Severity: Notice --> Undefined variable: pass_min C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 16
ERROR - 2016-03-27 00:54:30 --> Severity: Notice --> Undefined variable: pass_max C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 17
ERROR - 2016-03-27 00:54:30 --> Severity: Notice --> Undefined variable: user_min C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 18
ERROR - 2016-03-27 00:54:30 --> Severity: Notice --> Undefined variable: case_sensitive C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 19
ERROR - 2016-03-27 00:54:30 --> Severity: Notice --> Undefined variable: user_max C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 20
ERROR - 2016-03-27 00:54:30 --> Severity: Warning --> Missing argument 1 for Create_users::genUsername(), called in C:\MAMP\htdocs\horse\application\controllers\Test_scripts.php on line 38 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 83
ERROR - 2016-03-27 00:54:30 --> Severity: Warning --> Missing argument 2 for Create_users::genUsername(), called in C:\MAMP\htdocs\horse\application\controllers\Test_scripts.php on line 38 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 83
ERROR - 2016-03-27 00:54:30 --> Severity: Notice --> Undefined variable: min C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 86
ERROR - 2016-03-27 00:54:30 --> Severity: Notice --> Undefined variable: max C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 86
ERROR - 2016-03-27 00:56:00 --> Severity: Warning --> Missing argument 1 for Create_users::__construct(), called in C:\MAMP\htdocs\horse\system\core\Loader.php on line 353 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 14
ERROR - 2016-03-27 00:56:00 --> Severity: Warning --> Missing argument 2 for Create_users::__construct(), called in C:\MAMP\htdocs\horse\system\core\Loader.php on line 353 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 14
ERROR - 2016-03-27 00:56:00 --> Severity: Warning --> Missing argument 3 for Create_users::__construct(), called in C:\MAMP\htdocs\horse\system\core\Loader.php on line 353 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 14
ERROR - 2016-03-27 00:56:00 --> Severity: Warning --> Missing argument 4 for Create_users::__construct(), called in C:\MAMP\htdocs\horse\system\core\Loader.php on line 353 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 14
ERROR - 2016-03-27 00:56:00 --> Severity: Warning --> Missing argument 5 for Create_users::__construct(), called in C:\MAMP\htdocs\horse\system\core\Loader.php on line 353 and defined C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 14
ERROR - 2016-03-27 00:56:00 --> Severity: Notice --> Undefined variable: pass_min C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 16
ERROR - 2016-03-27 00:56:00 --> Severity: Notice --> Undefined variable: pass_max C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 17
ERROR - 2016-03-27 00:56:00 --> Severity: Notice --> Undefined variable: user_min C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 18
ERROR - 2016-03-27 00:56:00 --> Severity: Notice --> Undefined variable: case_sensitive C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 19
ERROR - 2016-03-27 00:56:00 --> Severity: Notice --> Undefined variable: user_max C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 20
ERROR - 2016-03-27 00:58:04 --> Severity: Notice --> Uninitialized string offset: 26 C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 34
ERROR - 2016-03-27 00:58:04 --> Severity: Notice --> Uninitialized string offset: 26 C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 34
ERROR - 2016-03-27 00:58:04 --> Severity: Notice --> Uninitialized string offset: 26 C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 34
ERROR - 2016-03-27 00:58:04 --> Severity: Notice --> Uninitialized string offset: 26 C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 34
ERROR - 2016-03-27 00:58:04 --> Severity: Notice --> Uninitialized string offset: 26 C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 34
ERROR - 2016-03-27 00:58:04 --> Severity: Notice --> Uninitialized string offset: 26 C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 34
ERROR - 2016-03-27 00:58:04 --> Severity: Notice --> Uninitialized string offset: 26 C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 34
ERROR - 2016-03-27 00:58:04 --> Severity: Notice --> Uninitialized string offset: 26 C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 34
ERROR - 2016-03-27 00:58:04 --> Severity: Notice --> Uninitialized string offset: 26 C:\MAMP\htdocs\horse\application\models\Test\Create_users.php 34
ERROR - 2016-03-27 01:01:58 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 01:01:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 01:19:54 --> Severity: Notice --> Undefined property: My_uploads::$common C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 37
ERROR - 2016-03-27 01:19:54 --> Severity: error --> Exception: Call to a member function paginateResults() on null C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 37
ERROR - 2016-03-27 01:21:01 --> Severity: Notice --> Undefined property: My_uploads::$common C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 37
ERROR - 2016-03-27 01:21:01 --> Severity: error --> Exception: Call to a member function paginateResults() on null C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 37
ERROR - 2016-03-27 01:24:49 --> Severity: Notice --> Undefined index: videos C:\MAMP\htdocs\horse\application\models\Common.php 18
ERROR - 2016-03-27 01:26:16 --> Severity: Warning --> Division by zero C:\MAMP\htdocs\horse\application\models\Common.php 19
ERROR - 2016-03-27 01:46:48 --> Severity: Notice --> Undefined index: videos C:\MAMP\htdocs\horse\application\models\Common.php 18
ERROR - 2016-03-27 01:46:48 --> Severity: Warning --> Division by zero C:\MAMP\htdocs\horse\application\models\Common.php 19
ERROR - 2016-03-27 01:47:51 --> Severity: Notice --> Undefined index: videos C:\MAMP\htdocs\horse\application\models\Common.php 18
ERROR - 2016-03-27 01:55:13 --> Severity: Notice --> Undefined index: videos C:\MAMP\htdocs\horse\application\models\Common.php 18
ERROR - 2016-03-27 02:04:16 --> Severity: Notice --> Undefined index: videos C:\MAMP\htdocs\horse\application\models\Common.php 18
ERROR - 2016-03-27 02:05:43 --> Severity: Notice --> Undefined index: videos C:\MAMP\htdocs\horse\application\models\Common.php 18
ERROR - 2016-03-27 02:05:54 --> Severity: Notice --> Undefined index: videos C:\MAMP\htdocs\horse\application\models\Common.php 18
ERROR - 2016-03-27 02:06:19 --> Severity: Notice --> Undefined index: videos C:\MAMP\htdocs\horse\application\models\Common.php 18
ERROR - 2016-03-27 02:08:03 --> Severity: Notice --> Undefined index: videos C:\MAMP\htdocs\horse\application\models\Common.php 18
ERROR - 2016-03-27 04:42:56 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 37
ERROR - 2016-03-27 05:12:38 --> Query error: Table 'horse_trainer.video_uploadss' doesn't exist - Invalid query: SELECT `video_uploads`.*, `scoring`.`total`
FROM `video_uploadss`
LEFT JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video_uploads`.`user_id` = '2'
ORDER BY `video_uploads`.`star_rating` DESC
 LIMIT 10, 10
ERROR - 2016-03-27 05:16:50 --> Query error: Table 'horse_trainer.video_uploadss' doesn't exist - Invalid query: SELECT `video_uploads`.*, `scoring`.`total`
FROM `video_uploadss`
LEFT JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video_uploads`.`user_id` = '2'
ORDER BY `video_uploads`.`star_rating` DESC
 LIMIT 10, 10
ERROR - 2016-03-27 05:17:56 --> Query error: Table 'horse_trainer.video_uploadss' doesn't exist - Invalid query: SELECT `video_uploads`.*, `scoring`.`total`
FROM `video_uploadss`
LEFT JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video_uploads`.`user_id` = '2'
ORDER BY `video_uploads`.`star_rating` DESC
 LIMIT 10, 30
ERROR - 2016-03-27 05:32:38 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:32:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:32:38 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 05:34:38 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:34:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:34:38 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 05:35:02 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:35:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:35:02 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 05:35:25 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:35:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:35:25 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 05:35:53 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:35:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:35:53 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 05:36:32 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:36:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:36:32 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 05:37:15 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:37:15 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 05:38:05 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:38:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:38:05 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 05:42:33 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:42:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 05:42:33 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 05:45:13 --> Severity: Warning --> Missing argument 2 for User_videos::getUsersVideos(), called in C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php on line 26 and defined C:\MAMP\htdocs\horse\application\models\User_videos.php 16
ERROR - 2016-03-27 05:45:13 --> Severity: Notice --> Undefined variable: page C:\MAMP\htdocs\horse\application\models\User_videos.php 41
ERROR - 2016-03-27 05:49:13 --> Severity: Notice --> Undefined index: latitude C:\MAMP\htdocs\horse\application\controllers\Login.php 50
ERROR - 2016-03-27 05:49:13 --> Severity: Notice --> Undefined index: longitude C:\MAMP\htdocs\horse\application\controllers\Login.php 51
ERROR - 2016-03-27 05:49:48 --> Severity: Notice --> Undefined index: latitude C:\MAMP\htdocs\horse\application\controllers\Login.php 50
ERROR - 2016-03-27 05:49:48 --> Severity: Notice --> Undefined index: longitude C:\MAMP\htdocs\horse\application\controllers\Login.php 51
ERROR - 2016-03-27 05:49:50 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 05:49:50 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 05:49:50 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 05:49:50 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 23
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:54:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:57:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 05:58:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:00:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:01:29 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 06:01:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 06:01:29 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 06:01:49 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 06:01:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 06:01:49 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:02:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:03:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:04:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:05:19 --> Severity: Error --> Class CI_Session_files_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::, SessionHandlerInterface::destroy) C:\MAMP\htdocs\horse\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2016-03-27 06:05:24 --> Severity: Error --> Class CI_Session_files_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::, SessionHandlerInterface::destroy) C:\MAMP\htdocs\horse\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2016-03-27 06:05:42 --> Severity: Error --> Class CI_Session_files_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::, SessionHandlerInterface::destroy) C:\MAMP\htdocs\horse\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2016-03-27 06:06:19 --> Severity: Error --> Class CI_Session_files_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::, SessionHandlerInterface::destroy) C:\MAMP\htdocs\horse\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2016-03-27 06:06:24 --> Severity: Error --> Class CI_Session_files_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::, SessionHandlerInterface::destroy) C:\MAMP\htdocs\horse\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2016-03-27 06:06:29 --> Severity: Error --> Class CI_Session_files_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::, SessionHandlerInterface::destroy) C:\MAMP\htdocs\horse\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2016-03-27 06:06:43 --> Severity: Error --> Class CI_Session_files_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::, SessionHandlerInterface::destroy) C:\MAMP\htdocs\horse\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2016-03-27 06:06:45 --> Severity: Error --> Class CI_Session_files_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::, SessionHandlerInterface::destroy) C:\MAMP\htdocs\horse\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2016-03-27 06:07:22 --> Severity: Error --> Class CI_Session_files_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::, SessionHandlerInterface::destroy) C:\MAMP\htdocs\horse\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2016-03-27 06:07:24 --> Severity: Error --> Class CI_Session_files_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::, SessionHandlerInterface::destroy) C:\MAMP\htdocs\horse\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2016-03-27 06:08:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2003): Can't connect to MySQL server on 'localhost' (10061) C:\MAMP\htdocs\horse\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2016-03-27 06:08:47 --> Unable to connect to the database
ERROR - 2016-03-27 06:09:14 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:09:14 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 06:09:14 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 06:09:14 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 24
ERROR - 2016-03-27 06:09:26 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:09:26 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 06:09:26 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 06:09:26 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 24
ERROR - 2016-03-27 06:09:41 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:09:41 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 06:09:41 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 06:09:41 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 24
ERROR - 2016-03-27 06:12:35 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 06:12:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 06:12:35 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 06:13:08 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 06:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-27 06:13:08 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\users\my-videos.php 98
ERROR - 2016-03-27 06:13:41 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:13:41 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 06:13:41 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 06:13:41 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 24
ERROR - 2016-03-27 06:16:50 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:16:50 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 7
ERROR - 2016-03-27 06:16:50 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 13
ERROR - 2016-03-27 06:16:50 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 17
ERROR - 2016-03-27 06:16:50 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 25
ERROR - 2016-03-27 06:17:19 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:17:19 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 7
ERROR - 2016-03-27 06:17:19 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 13
ERROR - 2016-03-27 06:17:19 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 17
ERROR - 2016-03-27 06:17:19 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 25
ERROR - 2016-03-27 06:18:31 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:18:31 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 7
ERROR - 2016-03-27 06:18:31 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 13
ERROR - 2016-03-27 06:18:31 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 17
ERROR - 2016-03-27 06:18:31 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 25
ERROR - 2016-03-27 06:18:53 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:18:53 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 06:18:53 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 06:18:53 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 24
ERROR - 2016-03-27 06:20:35 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:20:35 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 06:20:35 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 06:20:35 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 24
ERROR - 2016-03-27 06:20:42 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:20:42 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 06:20:42 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 06:20:42 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 24
ERROR - 2016-03-27 06:21:21 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:21:21 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 06:21:21 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 06:21:21 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 24
ERROR - 2016-03-27 06:21:27 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:21:27 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 06:21:27 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 06:21:27 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 24
ERROR - 2016-03-27 06:21:33 --> Severity: Notice --> Undefined variable: scored C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 6
ERROR - 2016-03-27 06:21:33 --> Severity: Notice --> Undefined variable: scoredThisMonth C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 12
ERROR - 2016-03-27 06:21:33 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 16
ERROR - 2016-03-27 06:21:33 --> Severity: Notice --> Undefined variable: credits C:\MAMP\htdocs\horse\application\views\coach\coach-dashboard.php 24
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:22:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:23:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 06:41:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Grandes C:\MAMP\htdocs\horse\system\core\Loader.php 344
ERROR - 2016-03-27 06:42:09 --> Severity: Notice --> Undefined property: Score_card::$Grades C:\MAMP\htdocs\horse\application\controllers\Coach\Score_card.php 37
ERROR - 2016-03-27 06:42:09 --> Severity: error --> Exception: Call to a member function needsGraded() on null C:\MAMP\htdocs\horse\application\controllers\Coach\Score_card.php 37
ERROR - 2016-03-27 06:43:40 --> Severity: Notice --> Undefined variable: videos C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 2
ERROR - 2016-03-27 06:47:38 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:47:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:47:38 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 98
ERROR - 2016-03-27 06:47:38 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 102
ERROR - 2016-03-27 06:48:06 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:48:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:48:06 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 98
ERROR - 2016-03-27 06:48:06 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 102
ERROR - 2016-03-27 06:50:03 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:50:03 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 98
ERROR - 2016-03-27 06:50:03 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 102
ERROR - 2016-03-27 06:52:36 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:52:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:52:36 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 98
ERROR - 2016-03-27 06:52:36 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 102
ERROR - 2016-03-27 06:53:45 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:53:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:53:45 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 98
ERROR - 2016-03-27 06:53:46 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 102
ERROR - 2016-03-27 06:53:57 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:53:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:53:57 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 98
ERROR - 2016-03-27 06:53:57 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 102
ERROR - 2016-03-27 06:57:42 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:57:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 06:57:42 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 98
ERROR - 2016-03-27 06:57:42 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 102
ERROR - 2016-03-27 07:00:06 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 07:00:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 07:00:06 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 98
ERROR - 2016-03-27 07:00:06 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 102
ERROR - 2016-03-27 07:00:44 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 07:00:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 07:00:44 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 07:00:44 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 07:00:51 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 07:00:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 07:00:51 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 07:00:51 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 07:01:30 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 07:01:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 07:01:30 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 07:01:30 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 16:54:29 --> Severity: Notice --> Undefined index: latitude C:\MAMP\htdocs\horse\application\controllers\Login.php 50
ERROR - 2016-03-27 16:54:29 --> Severity: Notice --> Undefined index: longitude C:\MAMP\htdocs\horse\application\controllers\Login.php 51
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:54:58 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 16:54:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 16:54:58 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 16:54:58 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 16:55:13 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 16:55:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 16:55:13 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 16:55:13 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 16:59:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:00:40 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:00:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:00:40 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 17:00:40 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 17:00:50 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:00:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:00:50 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 17:00:50 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 17:02:20 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:02:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:02:20 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 17:02:20 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 17:02:25 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:02:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:02:25 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 17:02:25 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:03:42 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:03:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:03:42 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 17:03:42 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:05:15 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:05:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:05:15 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 17:05:15 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 17:06:18 --> Severity: Notice --> Undefined index: latitude C:\MAMP\htdocs\horse\application\controllers\Login.php 50
ERROR - 2016-03-27 17:06:18 --> Severity: Notice --> Undefined index: longitude C:\MAMP\htdocs\horse\application\controllers\Login.php 51
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:09:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:14:17 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:14:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:14:17 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 17:14:17 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 17:18:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:00 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:18:08 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:18:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:18:08 --> Severity: Notice --> Undefined variable: links C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 99
ERROR - 2016-03-27 17:18:08 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 103
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:19:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:20:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:21:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:22:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:24:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:25:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:26:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:27:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:28:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:32:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:33:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:34:24 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:34 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:35:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-27 17:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\coach\needs-scored.php 10
