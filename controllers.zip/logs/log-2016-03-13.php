<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-13 10:17:07 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 10:17:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-13 10:17:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-13 10:17:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-13 10:17:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-13 10:17:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-13 10:17:22 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 10:17:23 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 10:17:27 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:17:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:17:32 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:17:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:17:43 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:17:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:17:49 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:17:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:19:19 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:19:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:21:51 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:21:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:26:38 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:26:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:26:49 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 10:26:49 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 10:28:00 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 10:28:00 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 10:28:55 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:28:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:29:01 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:29:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:29:27 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 10:29:28 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 10:37:16 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:37:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:37:36 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:37:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:39:58 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:39:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:40:12 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:40:49 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:40:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:41:29 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:41:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:41:40 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:41:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:43:46 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:43:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:48:58 --> Query error: Column 'user_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `video_uploads`
JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `user_id` = '2'
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2016-03-13 10:49:15 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `video_uploads`
JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video_uploads`.`user_id` = '2'
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2016-03-13 10:53:26 --> Severity: Notice --> Undefined property: stdClass::$total C:\MAMP\htdocs\horse\application\views\users\my-videos.php 69
ERROR - 2016-03-13 10:54:43 --> Severity: Notice --> Undefined property: stdClass::$total C:\MAMP\htdocs\horse\application\views\users\my-videos.php 70
ERROR - 2016-03-13 10:55:07 --> Severity: Notice --> Undefined property: stdClass::$total C:\MAMP\htdocs\horse\application\views\users\my-videos.php 70
ERROR - 2016-03-13 10:55:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OUTER JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video' at line 3 - Invalid query: SELECT *
FROM `video_uploads`
OUTER JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video_uploads`.`user_id` = '2'
ORDER BY `video_uploads`.`id` DESC
 LIMIT 20
ERROR - 2016-03-13 10:55:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OUTER JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video' at line 3 - Invalid query: SELECT *
FROM `video_uploads`
OUTER JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video_uploads`.`user_id` = '2'
ORDER BY `video_uploads`.`id` DESC
 LIMIT 20
ERROR - 2016-03-13 10:55:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OUTER JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video' at line 3 - Invalid query: SELECT *
FROM `video_uploads`
OUTER JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video_uploads`.`user_id` = '2'
ORDER BY `video_uploads`.`id` DESC
 LIMIT 20
ERROR - 2016-03-13 10:55:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OUTER JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video' at line 3 - Invalid query: SELECT *
FROM `video_uploads`
OUTER JOIN `scoring` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `video_uploads`.`user_id` = '2'
ORDER BY `video_uploads`.`id` DESC
 LIMIT 20
ERROR - 2016-03-13 10:57:27 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:57:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:57:59 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:57:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:58:19 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:58:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:58:22 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:58:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:58:41 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 10:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:12:14 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 12:12:14 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 12:12:25 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:12:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:13:47 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 12:13:47 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 12:13:49 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:13:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:35:29 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 12:35:29 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 12:35:32 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:35:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:39:19 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:39:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:39:20 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:39:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:39:27 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:39:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:39:43 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:44:57 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:44:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 12:46:40 --> Severity: Notice --> Undefined variable: profile_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 97
ERROR - 2016-03-13 12:46:50 --> Severity: Notice --> Undefined variable: email_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 96
ERROR - 2016-03-13 12:47:24 --> Severity: Notice --> Undefined variable: email_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 96
ERROR - 2016-03-13 12:47:24 --> Severity: Notice --> Undefined variable: profile_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 97
ERROR - 2016-03-13 12:47:35 --> Severity: Notice --> Undefined variable: email_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 96
ERROR - 2016-03-13 12:47:35 --> Severity: Notice --> Undefined variable: profile_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 97
ERROR - 2016-03-13 12:47:45 --> Severity: Notice --> Undefined variable: profile_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 97
ERROR - 2016-03-13 12:47:57 --> Severity: Notice --> Undefined variable: emails_on C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 94
ERROR - 2016-03-13 12:47:57 --> Severity: Notice --> Undefined variable: newsletter C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 95
ERROR - 2016-03-13 12:47:57 --> Severity: Notice --> Undefined variable: profile_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 97
ERROR - 2016-03-13 13:15:10 --> Severity: error --> Exception: Class 'ConstantContact' not found C:\MAMP\htdocs\horse\application\controllers\User\Test.php 18
ERROR - 2016-03-13 13:15:40 --> Severity: error --> Exception: Class 'Ctct\ConstantContact' not found C:\MAMP\htdocs\horse\application\controllers\User\Test.php 23
ERROR - 2016-03-13 13:15:47 --> Severity: error --> Exception: Class 'Ctct\ConstantContact' not found C:\MAMP\htdocs\horse\application\controllers\User\Test.php 23
ERROR - 2016-03-13 13:25:17 --> Severity: error --> Exception: Class 'ConstantContact' not found C:\MAMP\htdocs\horse\application\controllers\User\Test.php 20
ERROR - 2016-03-13 13:25:59 --> Severity: error --> Exception: Class 'ConstantContact' not found C:\MAMP\htdocs\horse\application\controllers\User\Test.php 19
ERROR - 2016-03-13 13:27:26 --> Severity: error --> Exception: Class 'ConstantContact' not found C:\MAMP\htdocs\horse\application\controllers\User\Test.php 22
ERROR - 2016-03-13 13:32:16 --> Severity: error --> Exception: Class 'ConstantContact' not found C:\MAMP\htdocs\horse\application\controllers\User\Test.php 24
ERROR - 2016-03-13 13:32:48 --> Severity: error --> Exception: Class 'ConstantContact' not found C:\MAMP\htdocs\horse\application\controllers\User\Test.php 24
ERROR - 2016-03-13 13:33:29 --> Severity: error --> Exception: Call to a member function getBody() on null C:\MAMP\htdocs\horse\vendor\constantcontact\constantcontact\constantcontact\src\Ctct\Services\BaseService.php 103
ERROR - 2016-03-13 13:52:03 --> Severity: error --> Exception: Call to a member function getBody() on null C:\MAMP\htdocs\horse\vendor\constantcontact\constantcontact\constantcontact\src\Ctct\Services\BaseService.php 103
ERROR - 2016-03-13 13:55:40 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 13:55:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 13:55:44 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 13:55:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 87
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 90
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 93
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 93
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 96
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 105
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 108
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 111
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 111
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 114
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 123
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 126
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 129
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 129
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 132
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 141
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 144
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 147
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 147
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 150
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 159
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 162
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 165
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 165
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 168
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 177
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 180
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 183
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 183
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 186
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 195
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 198
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 201
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 201
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 204
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 214
ERROR - 2016-03-13 13:57:07 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 217
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 220
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 220
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 223
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 232
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 235
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 238
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 238
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 241
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 252
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 255
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 258
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 258
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 261
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 268
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 271
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 274
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 274
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 277
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 284
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 287
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 290
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 290
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 293
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 300
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 303
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 306
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 306
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 309
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 316
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 319
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 322
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 322
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 325
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 332
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 335
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 338
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 338
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 341
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 351
ERROR - 2016-03-13 13:57:08 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 357
ERROR - 2016-03-13 13:58:17 --> Severity: Notice --> Undefined property: stdClass::$video_id C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-13 13:58:36 --> Severity: Notice --> Undefined property: stdClass::$video_id C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 24
ERROR - 2016-03-13 13:59:09 --> Severity: Notice --> Undefined property: stdClass::$video_id C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 24
ERROR - 2016-03-13 13:59:24 --> Severity: Notice --> Undefined property: stdClass::$video_id C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 26
ERROR - 2016-03-13 13:59:55 --> Severity: Notice --> Undefined property: stdClass::$video_id C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 25
ERROR - 2016-03-13 14:00:30 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 25
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 90
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 93
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 96
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 96
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 99
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 108
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 111
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 114
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 114
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 117
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 126
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 129
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 132
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 132
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 135
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 144
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 147
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 150
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 150
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 153
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 162
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 165
ERROR - 2016-03-13 14:02:22 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 168
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 168
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 171
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 180
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 183
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 186
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 186
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 189
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 198
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 201
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 204
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 204
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 207
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 217
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 220
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 223
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 223
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 226
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 235
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 238
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 241
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 241
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 244
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 255
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 258
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 261
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 261
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 264
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 271
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 274
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 277
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 277
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 280
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 287
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 290
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 293
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 293
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 296
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 303
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 306
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 309
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 309
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 312
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 319
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 322
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 325
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 325
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 328
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 335
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 338
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 341
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 341
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 344
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 354
ERROR - 2016-03-13 14:02:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 360
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 91
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 94
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 100
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 109
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 112
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 118
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 127
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 130
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 136
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 145
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 148
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 154
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 163
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 166
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 172
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 181
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 184
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 190
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 199
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 202
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 208
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 218
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 221
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 227
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 236
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 239
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 245
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 256
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 259
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 265
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 272
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 275
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 281
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 288
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 291
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 297
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 304
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 307
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 313
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 320
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 323
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 329
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 336
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 339
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 345
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 355
ERROR - 2016-03-13 14:03:06 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 361
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 91
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 94
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 100
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 109
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 112
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 118
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 127
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 130
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 136
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 145
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 148
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 154
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 163
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 166
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 172
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 181
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 184
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 190
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 199
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 202
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 208
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 218
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 221
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 227
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 236
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 239
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 245
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 256
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 259
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 265
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 272
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 275
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 281
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 288
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 291
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 297
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 304
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 307
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 313
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 320
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 323
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 329
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 336
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 339
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 345
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 355
ERROR - 2016-03-13 14:03:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 361
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 91
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 94
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 100
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 109
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 112
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 118
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 127
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 130
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 136
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 145
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 148
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 154
ERROR - 2016-03-13 14:03:34 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 163
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 166
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 172
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 181
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 184
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 190
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 199
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 202
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 208
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 218
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 221
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 227
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 236
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 239
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 245
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 256
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 259
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 265
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 272
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 275
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 281
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 288
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 291
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 297
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 304
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 307
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 313
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 320
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 323
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 329
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 336
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 339
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 345
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 355
ERROR - 2016-03-13 14:03:35 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 361
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 91
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 94
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 100
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 109
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 112
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 118
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 127
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 130
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 136
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 145
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 148
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 154
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 163
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 166
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 172
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 181
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 184
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 190
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 199
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 202
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 208
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 218
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 221
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 227
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 236
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 239
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 245
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 256
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 259
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 265
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 272
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 275
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 281
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 288
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 291
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:05:14 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 297
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 304
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 307
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 313
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 320
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 323
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 329
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 336
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 339
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 345
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 355
ERROR - 2016-03-13 14:05:15 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 361
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 91
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 94
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 100
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 109
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 112
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 118
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 127
ERROR - 2016-03-13 14:05:29 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 130
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 136
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 145
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 148
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 154
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 163
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 166
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 172
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 181
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 184
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 190
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 199
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 202
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 208
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 218
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 221
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 227
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 236
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 239
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 245
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 256
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 259
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 265
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 272
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 275
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 281
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 288
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 291
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 297
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 304
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 307
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 313
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 320
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 323
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 329
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 336
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 339
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 345
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 355
ERROR - 2016-03-13 14:05:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 361
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 91
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 94
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 100
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 109
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 112
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 118
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 127
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 130
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 136
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 145
ERROR - 2016-03-13 14:06:01 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 148
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 154
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 163
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 166
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 172
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 181
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 184
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 190
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 199
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 202
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 208
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 218
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 221
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 227
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 236
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 239
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 245
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 256
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 259
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 265
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 272
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 275
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 281
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 288
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 291
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 297
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 304
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 307
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 313
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 320
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 323
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 329
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 336
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 339
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 345
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 355
ERROR - 2016-03-13 14:06:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 361
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 91
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 94
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 97
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 100
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 109
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 112
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 115
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 118
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 127
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 130
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 133
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 136
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 145
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 148
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 151
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 154
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 163
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 166
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 169
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 172
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 181
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 184
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 187
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 190
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 199
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 202
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 205
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 208
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 218
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 221
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 224
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 227
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 236
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 239
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 242
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 245
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 256
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 259
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 262
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 265
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 272
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 275
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 278
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 281
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 288
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 291
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 294
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 297
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 304
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 307
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 310
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 313
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 320
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 323
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 326
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 329
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 336
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 339
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 342
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 345
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 355
ERROR - 2016-03-13 14:06:26 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 361
ERROR - 2016-03-13 14:20:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Settings C:\MAMP\htdocs\horse\system\core\Loader.php 344
ERROR - 2016-03-13 14:21:52 --> Severity: Notice --> Undefined property: Payment::$settings C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 24
ERROR - 2016-03-13 14:21:52 --> Severity: error --> Exception: Call to a member function getSetting() on null C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 24
ERROR - 2016-03-13 17:37:51 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 19:51:02 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\MAMP\htdocs\horse\application\models\Process_payment.php 53
ERROR - 2016-03-13 19:51:02 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\MAMP\htdocs\horse\application\models\Process_payment.php 53
ERROR - 2016-03-13 19:51:20 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\MAMP\htdocs\horse\application\models\Process_payment.php 53
ERROR - 2016-03-13 19:51:43 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\MAMP\htdocs\horse\application\models\Process_payment.php 53
ERROR - 2016-03-13 19:52:23 --> Severity: error --> Exception: Call to undefined method Payment::processPayment() C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 52
ERROR - 2016-03-13 19:52:57 --> Severity: error --> Exception: Call to undefined method Payment::process() C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 52
ERROR - 2016-03-13 19:53:26 --> Severity: error --> Exception: Call to undefined method Payment::process() C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 52
ERROR - 2016-03-13 19:53:50 --> Severity: Notice --> Undefined property: Payment::$process_payment C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 51
ERROR - 2016-03-13 19:53:50 --> Severity: error --> Exception: Call to a member function checkTotalAmount() on null C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 51
ERROR - 2016-03-13 19:54:41 --> Severity: error --> Exception: Call to undefined method Payment::process() C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 52
ERROR - 2016-03-13 19:55:37 --> Severity: error --> Exception: Call to undefined method Payment::process() C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 52
ERROR - 2016-03-13 19:55:57 --> Severity: error --> Exception: Call to undefined method Payment::process() C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 52
ERROR - 2016-03-13 19:56:19 --> Severity: Notice --> Undefined property: Payment::$process_payment C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 55
ERROR - 2016-03-13 19:56:19 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 55
ERROR - 2016-03-13 19:58:21 --> Severity: Notice --> Undefined index: amount C:\MAMP\htdocs\horse\application\models\Process_payment.php 67
ERROR - 2016-03-13 19:58:21 --> Query error: Column 'amount' cannot be null - Invalid query: INSERT INTO `payments` (`trans_id`, `approval_code`, `paid_on`, `amount`, `user_id`) VALUES ('2252853357', 'OHPDMC', '2016-03-13 19:58:21', NULL, '2')
ERROR - 2016-03-13 20:02:40 --> Severity: Notice --> Undefined property: Payment::$process_payment C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 53
ERROR - 2016-03-13 20:02:40 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 53
ERROR - 2016-03-13 20:03:45 --> Severity: Notice --> Undefined property: Payment::$process_payment C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 53
ERROR - 2016-03-13 20:03:45 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 53
ERROR - 2016-03-13 20:07:40 --> Severity: Notice --> Undefined property: Payment::$process_payment C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 53
ERROR - 2016-03-13 20:07:40 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 53
ERROR - 2016-03-13 20:19:38 --> Severity: Notice --> Undefined property: Payment::$process_payment C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 53
ERROR - 2016-03-13 20:19:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 53
ERROR - 2016-03-13 20:30:44 --> Severity: error --> Exception: syntax error, unexpected ')' C:\MAMP\htdocs\horse\application\models\Process_payment.php 82
ERROR - 2016-03-13 20:30:45 --> Severity: error --> Exception: syntax error, unexpected ')' C:\MAMP\htdocs\horse\application\models\Process_payment.php 82
ERROR - 2016-03-13 20:30:52 --> Severity: error --> Exception: syntax error, unexpected ')' C:\MAMP\htdocs\horse\application\models\Process_payment.php 82
ERROR - 2016-03-13 20:31:31 --> Severity: Notice --> Use of undefined constant data - assumed 'data' C:\MAMP\htdocs\horse\application\models\Process_payment.php 82
ERROR - 2016-03-13 20:31:31 --> Severity: Warning --> Illegal string offset 'coaching_credits' C:\MAMP\htdocs\horse\application\models\Process_payment.php 82
ERROR - 2016-03-13 21:50:44 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 21:50:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 21:50:51 --> Severity: Notice --> Undefined property: Score_card::$grades C:\MAMP\htdocs\horse\application\controllers\User\Score_card.php 37
ERROR - 2016-03-13 21:50:51 --> Severity: error --> Exception: Call to a member function getScoreCard() on null C:\MAMP\htdocs\horse\application\controllers\User\Score_card.php 37
ERROR - 2016-03-13 21:51:47 --> Severity: Notice --> Undefined property: Score_card::$grades C:\MAMP\htdocs\horse\application\controllers\User\Score_card.php 37
ERROR - 2016-03-13 21:51:47 --> Severity: error --> Exception: Call to a member function getScoreCard() on null C:\MAMP\htdocs\horse\application\controllers\User\Score_card.php 37
ERROR - 2016-03-13 21:51:49 --> Severity: Notice --> Undefined property: Score_card::$grades C:\MAMP\htdocs\horse\application\controllers\User\Score_card.php 37
ERROR - 2016-03-13 21:51:49 --> Severity: error --> Exception: Call to a member function getScoreCard() on null C:\MAMP\htdocs\horse\application\controllers\User\Score_card.php 37
ERROR - 2016-03-13 22:04:16 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 22:04:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-13 22:04:22 --> Geolocation => Invalid API key.
ERROR - 2016-03-13 22:04:22 --> Geolocation => Invalid API key.
