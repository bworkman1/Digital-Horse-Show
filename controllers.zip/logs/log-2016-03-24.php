<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-24 00:19:07 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-24 00:19:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
