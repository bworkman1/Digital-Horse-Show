<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-20 00:41:04 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\MAMP\htdocs\horse\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2016-03-20 00:41:04 --> Unable to connect to the database
ERROR - 2016-03-20 00:43:25 --> Severity: Notice --> Undefined index: latitude C:\MAMP\htdocs\horse\application\controllers\Login.php 54
ERROR - 2016-03-20 00:43:25 --> Severity: Notice --> Undefined index: longitude C:\MAMP\htdocs\horse\application\controllers\Login.php 55
ERROR - 2016-03-20 00:43:31 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\payment-page.php 19
ERROR - 2016-03-20 00:43:31 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\payment-page.php 26
ERROR - 2016-03-20 00:43:31 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\payment-page.php 123
ERROR - 2016-03-20 00:43:31 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\payment-page.php 124
ERROR - 2016-03-20 00:43:55 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\payment-page.php 19
ERROR - 2016-03-20 00:43:55 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\payment-page.php 26
ERROR - 2016-03-20 00:43:55 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\payment-page.php 123
ERROR - 2016-03-20 00:43:55 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\payment-page.php 124
ERROR - 2016-03-20 02:00:24 --> Query error: Table 'horse_trainer.payments' doesn't exist - Invalid query: INSERT INTO `payments` (`trans_id`, `approval_code`, `paid_on`, `amount`, `user_id`) VALUES ('2253285501', 'BH0AQM', '2016-03-20 02:00:24', '95.94', '2')
ERROR - 2016-03-20 02:00:51 --> Query error: Table 'horse_trainer.payments' doesn't exist - Invalid query: INSERT INTO `payments` (`trans_id`, `approval_code`, `paid_on`, `amount`, `user_id`) VALUES ('2253285505', 'GQ6IAM', '2016-03-20 02:00:51', '95.94', '2')
ERROR - 2016-03-20 02:04:16 --> Query error: Table 'horse_trainer.payments' doesn't exist - Invalid query: INSERT INTO `payments` (`trans_id`, `approval_code`, `paid_on`, `amount`, `user_id`) VALUES ('2253285623', 'D3IX11', '2016-03-20 02:04:16', '95.94', '2')
ERROR - 2016-03-20 02:06:18 --> Query error: Table 'horse_trainer.payments' doesn't exist - Invalid query: INSERT INTO `payments` (`trans_id`, `approval_code`, `paid_on`, `amount`, `user_id`) VALUES ('2253285667', '88FPR0', '2016-03-20 02:06:18', '95.94', '2')
ERROR - 2016-03-20 02:08:58 --> Query error: Unknown column 'amount' in 'field list' - Invalid query: INSERT INTO `payments` (`trans_id`, `approval_code`, `paid_on`, `amount`, `user_id`) VALUES ('2253285738', '6YNCCM', '2016-03-20 02:08:58', '95.94', '2')
ERROR - 2016-03-20 02:09:35 --> Query error: Unknown column 'amount' in 'field list' - Invalid query: INSERT INTO `payments` (`trans_id`, `approval_code`, `paid_on`, `amount`, `user_id`) VALUES ('2253285763', 'ZXN3HU', '2016-03-20 02:09:35', '95.94', '2')
ERROR - 2016-03-20 02:10:29 --> Severity: Notice --> Undefined property: stdClass::$coaching_credits C:\MAMP\htdocs\horse\application\models\Process_payment.php 82
ERROR - 2016-03-20 02:10:29 --> Severity: Notice --> Use of undefined constant data - assumed 'data' C:\MAMP\htdocs\horse\application\models\Process_payment.php 82
ERROR - 2016-03-20 02:10:29 --> Severity: Warning --> Illegal string offset 'coaching_credits' C:\MAMP\htdocs\horse\application\models\Process_payment.php 82
ERROR - 2016-03-20 02:10:29 --> Query error: Unknown column 'coaching_credits' in 'field list' - Invalid query: UPDATE `users` SET `coaching_credits` = 0
WHERE `id` = '2'
ERROR - 2016-03-20 02:12:14 --> Severity: Notice --> Use of undefined constant data - assumed 'data' C:\MAMP\htdocs\horse\application\models\Process_payment.php 82
ERROR - 2016-03-20 02:12:14 --> Severity: Warning --> Illegal string offset 'coaching_credits' C:\MAMP\htdocs\horse\application\models\Process_payment.php 82
ERROR - 2016-03-20 02:13:59 --> Severity: Notice --> Undefined property: Payment::$process_payment C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 55
ERROR - 2016-03-20 02:13:59 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 55
ERROR - 2016-03-20 02:21:10 --> Severity: Notice --> Undefined property: Payment::$process_payment C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 55
ERROR - 2016-03-20 02:21:10 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 55
ERROR - 2016-03-20 02:26:13 --> Severity: Notice --> Undefined property: Payment::$process_payment C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 55
ERROR - 2016-03-20 02:26:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 55
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 6
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 7
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 7
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 12
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 12
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 13
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 13
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 10
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 12
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 30
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 36
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 42
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 49
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 55
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 55
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 86
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 89
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 92
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 92
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 95
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 104
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 107
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 110
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 110
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 113
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 122
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 125
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 128
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 128
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 131
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 140
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 143
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 146
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 146
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 149
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 158
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 161
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 164
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 164
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 167
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 176
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 179
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 182
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 182
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 185
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 194
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 197
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 200
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 200
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 203
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 213
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 216
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 219
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 219
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 222
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 231
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 234
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 237
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 237
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 240
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 251
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 254
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 257
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 257
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 260
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 267
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 270
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 273
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 273
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 276
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 283
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 286
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 289
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 289
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 292
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 299
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 302
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 305
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 305
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 308
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 315
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 318
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 321
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 321
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 324
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 331
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 334
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 337
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 337
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 340
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 350
ERROR - 2016-03-20 02:56:38 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 356
ERROR - 2016-03-20 02:59:12 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\MAMP\htdocs\horse\application\controllers\User\Score_card.php 41
ERROR - 2016-03-20 02:59:21 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-20 02:59:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-20 02:59:32 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\MAMP\htdocs\horse\application\controllers\User\Score_card.php 41
ERROR - 2016-03-20 03:18:19 --> Query error: Table 'horse_trainer.video_uploadss' doesn't exist - Invalid query: SELECT `id`
FROM `video_uploadss`
WHERE `id` < 114
AND `user_id` = '2'
 LIMIT 1
ERROR - 2016-03-20 03:48:32 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-20 03:48:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-20 03:52:36 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-20 03:52:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-20 04:14:20 --> Query error: Unknown column 'user.first_name' in 'field list' - Invalid query: SELECT `payments`.`coach_id`, `user`.`first_name`, `user`.`last_name`
FROM `payments`
JOIN `users` ON `users`.`id` = `payments`.`coach_id`
WHERE `remaining` >0
AND `user_id` = '2'
ERROR - 2016-03-20 04:15:37 --> Severity: Notice --> Undefined property: stdClass::$id C:\MAMP\htdocs\horse\application\views\users\upload-video.php 70
ERROR - 2016-03-20 04:16:18 --> Severity: Notice --> Undefined property: stdClass::$id C:\MAMP\htdocs\horse\application\views\users\upload-video.php 70
ERROR - 2016-03-20 04:18:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\MAMP\htdocs\horse\application\views\users\upload-video.php 71
ERROR - 2016-03-20 04:30:48 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\MAMP\htdocs\horse\application\views\users\upload-video.php 78
ERROR - 2016-03-20 04:31:01 --> Severity: Notice --> Undefined property: stdClass::$id C:\MAMP\htdocs\horse\application\views\users\upload-video.php 77
ERROR - 2016-03-20 04:31:23 --> Severity: Notice --> Undefined property: stdClass::$id C:\MAMP\htdocs\horse\application\views\users\upload-video.php 77
ERROR - 2016-03-20 04:31:51 --> Severity: Notice --> Undefined property: stdClass::$id C:\MAMP\htdocs\horse\application\views\users\upload-video.php 77
ERROR - 2016-03-20 04:48:56 --> Severity: Notice --> Undefined index: coach C:\MAMP\htdocs\horse\application\models\Uploads.php 224
ERROR - 2016-03-20 04:48:56 --> Query error: Unknown column 'coach' in 'field list' - Invalid query: INSERT INTO `video_uploads` (`user_id`, `size`, `path`, `ext`, `orig_name`, `client_name`, `encypt_name`, `comp_name`, `comp_class`, `date`, `horse_name`, `file_type`, `thumb`, `star_rating`, `location`, `cords`, `coach`) VALUES ('2', 441, '/uploads/bworkman/2016/03/f52d52a508e5006e7deb38d51ee05f50.mp4', '.mp4', 'Teaching_a_dog_to_meow.mp4', 'Testing 9 Left before upload', 'f52d52a508e5006e7deb38d51ee05f50.mp4', 'Test', 'test', '03/12/2016', 'Clyde', 'video/mp4', 'uploads/bworkman/2016/03/thumbs/f52d52a508e5006e7deb38d51ee05f50.jpg', 0, '4944 North High Street, Columbus, OH, United States', '40.06336950000001|-83.01837990000001', NULL)
ERROR - 2016-03-20 04:49:03 --> Severity: Notice --> Undefined index: coach C:\MAMP\htdocs\horse\application\models\Uploads.php 224
ERROR - 2016-03-20 04:49:03 --> Query error: Unknown column 'coach' in 'field list' - Invalid query: INSERT INTO `video_uploads` (`user_id`, `size`, `path`, `ext`, `orig_name`, `client_name`, `encypt_name`, `comp_name`, `comp_class`, `date`, `horse_name`, `file_type`, `thumb`, `star_rating`, `location`, `cords`, `coach`) VALUES ('2', 441, '/uploads/bworkman/2016/03/b8841b6ccbfae7cd14a7eb556557d996.mp4', '.mp4', 'Teaching_a_dog_to_meow.mp4', 'Testing 9 Left before upload', 'b8841b6ccbfae7cd14a7eb556557d996.mp4', 'Test', 'test', '03/12/2016', 'Clyde', 'video/mp4', 'uploads/bworkman/2016/03/thumbs/b8841b6ccbfae7cd14a7eb556557d996.jpg', 0, '4944 North High Street, Columbus, OH, United States', '40.06336950000001|-83.01837990000001', NULL)
ERROR - 2016-03-20 04:49:07 --> Severity: Notice --> Undefined index: coach C:\MAMP\htdocs\horse\application\models\Uploads.php 224
ERROR - 2016-03-20 04:49:07 --> Query error: Unknown column 'coach' in 'field list' - Invalid query: INSERT INTO `video_uploads` (`user_id`, `size`, `path`, `ext`, `orig_name`, `client_name`, `encypt_name`, `comp_name`, `comp_class`, `date`, `horse_name`, `file_type`, `thumb`, `star_rating`, `location`, `cords`, `coach`) VALUES ('2', 441, '/uploads/bworkman/2016/03/abe751042ef88bf025db619ace2e11b9.mp4', '.mp4', 'Teaching_a_dog_to_meow.mp4', 'Testing 9 Left before upload', 'abe751042ef88bf025db619ace2e11b9.mp4', 'Test', 'test', '03/12/2016', 'Clyde', 'video/mp4', 'uploads/bworkman/2016/03/thumbs/abe751042ef88bf025db619ace2e11b9.jpg', 0, '4944 North High Street, Columbus, OH, United States', '40.06336950000001|-83.01837990000001', NULL)
ERROR - 2016-03-20 04:49:23 --> Severity: Notice --> Undefined index: coach C:\MAMP\htdocs\horse\application\models\Uploads.php 224
ERROR - 2016-03-20 04:49:23 --> Query error: Unknown column 'coach' in 'field list' - Invalid query: INSERT INTO `video_uploads` (`user_id`, `size`, `path`, `ext`, `orig_name`, `client_name`, `encypt_name`, `comp_name`, `comp_class`, `date`, `horse_name`, `file_type`, `thumb`, `star_rating`, `location`, `cords`, `coach`) VALUES ('2', 441, '/uploads/bworkman/2016/03/992407cbc12f85dbd1b2b097b11b2805.mp4', '.mp4', 'Teaching_a_dog_to_meow.mp4', 'Testing 9 Left before upload', '992407cbc12f85dbd1b2b097b11b2805.mp4', 'Test', 'test', '03/12/2016', 'Clyde', 'video/mp4', 'uploads/bworkman/2016/03/thumbs/992407cbc12f85dbd1b2b097b11b2805.jpg', 0, '4944 North High Street, Columbus, OH, United States', '40.06336950000001|-83.01837990000001', NULL)
ERROR - 2016-03-20 04:52:59 --> Severity: Notice --> Undefined index: coach C:\MAMP\htdocs\horse\application\models\Uploads.php 224
ERROR - 2016-03-20 04:52:59 --> Query error: Unknown column 'coach' in 'field list' - Invalid query: INSERT INTO `video_uploads` (`user_id`, `size`, `path`, `ext`, `orig_name`, `client_name`, `encypt_name`, `comp_name`, `comp_class`, `date`, `horse_name`, `file_type`, `thumb`, `star_rating`, `location`, `cords`, `coach`) VALUES ('2', 8551.58, '/uploads/bworkman/2016/03/3aa37293694472cf8c8419f802793a89.mp4', '.mp4', 'PureWow_Presents_How_to_Clean_Silver_with_Ketchup.mp4', 'Video name', '3aa37293694472cf8c8419f802793a89.mp4', 'Ohio State Fair ', 'E-Class', '03/24/2016', 'Bonnie 5', 'video/mp4', 'uploads/bworkman/2016/03/thumbs/3aa37293694472cf8c8419f802793a89.jpg', 0, '585 Mill Street, Utica, OH, United States', '40.2330179|-82.44153990000001', NULL)
ERROR - 2016-03-20 04:53:52 --> Severity: Notice --> Undefined index: coach C:\MAMP\htdocs\horse\application\models\Uploads.php 224
ERROR - 2016-03-20 04:53:52 --> Severity: Notice --> Undefined index: coach C:\MAMP\htdocs\horse\application\models\Uploads.php 229
ERROR - 2016-03-20 04:53:52 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\models\Uploads.php 245
ERROR - 2016-03-20 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$remaining C:\MAMP\htdocs\horse\application\models\Uploads.php 245
ERROR - 2016-03-20 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$id C:\MAMP\htdocs\horse\application\models\Uploads.php 246
ERROR - 2016-03-20 04:59:31 --> Severity: Notice --> Undefined index: cords C:\MAMP\htdocs\horse\application\models\Uploads.php 223
ERROR - 2016-03-20 04:59:31 --> Query error: Table 'horse_trainer.userss' doesn't exist - Invalid query: UPDATE `userss` SET `coaching_credits` = '9'
WHERE `id` = '2'
ERROR - 2016-03-20 05:00:22 --> Severity: Notice --> Undefined index: cords C:\MAMP\htdocs\horse\application\models\Uploads.php 223
ERROR - 2016-03-20 05:00:22 --> Query error: Table 'horse_trainer.paymentss' doesn't exist - Invalid query: SELECT *
FROM `paymentss`
WHERE `remaining` >0
AND `user_id` = '2'
AND `coach_id` = '4'
ERROR - 2016-03-20 05:01:32 --> Query error: Table 'horse_trainer.paymentss' doesn't exist - Invalid query: SELECT *
FROM `paymentss`
WHERE `remaining` >0
AND `user_id` = '2'
AND `coach_id` = '4'
ERROR - 2016-03-20 05:04:57 --> Severity: Notice --> Undefined index: cords C:\MAMP\htdocs\horse\application\models\Uploads.php 223
ERROR - 2016-03-20 05:05:14 --> Severity: Notice --> Undefined index: cords C:\MAMP\htdocs\horse\application\models\Uploads.php 223
ERROR - 2016-03-20 05:06:57 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-20 05:06:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-20 05:08:29 --> Severity: Notice --> Undefined index: cords C:\MAMP\htdocs\horse\application\models\Uploads.php 223
ERROR - 2016-03-20 05:25:49 --> Severity: error --> Exception: Call to undefined method Payment::getUsersPayments() C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 81
ERROR - 2016-03-20 05:26:08 --> Severity: error --> Exception: Call to undefined method Payment::getUsersPayments() C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 81
ERROR - 2016-03-20 05:27:27 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\my-payments.php 18
ERROR - 2016-03-20 05:33:22 --> Query error: Table 'horse_trainer.paymentss' doesn't exist - Invalid query: SELECT *
FROM `paymentss`
WHERE 0 = 'id'
AND 1 = '2'
ERROR - 2016-03-20 05:33:45 --> Query error: Table 'horse_trainer.paymentss' doesn't exist - Invalid query: SELECT *
FROM `paymentss`
WHERE `id` = '2'
ERROR - 2016-03-20 05:34:28 --> Query error: Table 'horse_trainer.paymentss' doesn't exist - Invalid query: SELECT *
FROM `paymentss`
WHERE `id` = '2'
ERROR - 2016-03-20 05:36:30 --> Query error: Table 'horse_trainer.paymentss' doesn't exist - Invalid query: SELECT *
FROM `paymentss`
WHERE `id` = '2'
ERROR - 2016-03-20 05:36:34 --> Query error: Table 'horse_trainer.paymentss' doesn't exist - Invalid query: SELECT *
FROM `paymentss`
WHERE `id` = '2'
ERROR - 2016-03-20 05:37:24 --> Query error: Table 'horse_trainer.paymentss' doesn't exist - Invalid query: SELECT *
FROM `paymentss`
WHERE `user_id` = '2'
ORDER BY `id` DESC
ERROR - 2016-03-20 05:37:33 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\views\users\my-payments.php 19
ERROR - 2016-03-20 05:37:33 --> Severity: Notice --> Undefined property: stdClass::$coach C:\MAMP\htdocs\horse\application\views\users\my-payments.php 21
ERROR - 2016-03-20 05:37:33 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\views\users\my-payments.php 19
ERROR - 2016-03-20 05:37:33 --> Severity: Notice --> Undefined property: stdClass::$coach C:\MAMP\htdocs\horse\application\views\users\my-payments.php 21
ERROR - 2016-03-20 05:38:03 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\views\users\my-payments.php 19
ERROR - 2016-03-20 05:38:03 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\views\users\my-payments.php 19
ERROR - 2016-03-20 05:43:37 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ']' C:\MAMP\htdocs\horse\application\views\users\my-payments.php 31
ERROR - 2016-03-20 05:56:14 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-20 05:56:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-20 06:14:23 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-20 06:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
