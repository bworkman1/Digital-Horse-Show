<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-06 00:07:50 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-06 00:08:04 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-06 00:09:38 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-06 00:11:15 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-06 00:11:55 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
