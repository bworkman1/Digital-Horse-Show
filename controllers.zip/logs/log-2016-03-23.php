<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-23 23:50:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2003): Can't connect to MySQL server on 'localhost' (10061) C:\MAMP\htdocs\horse\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2016-03-23 23:50:57 --> Unable to connect to the database
ERROR - 2016-03-23 23:51:21 --> Severity: Notice --> Undefined index: latitude C:\MAMP\htdocs\horse\application\controllers\Login.php 50
ERROR - 2016-03-23 23:51:21 --> Severity: Notice --> Undefined index: longitude C:\MAMP\htdocs\horse\application\controllers\Login.php 51
