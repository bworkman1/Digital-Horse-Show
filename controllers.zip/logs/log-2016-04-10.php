<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-10 12:19:52 --> Geolocation => Invalid API key.
ERROR - 2016-04-10 12:39:45 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:39:56 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:40:07 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:40:13 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:41:39 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:41:46 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:42:51 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:44:34 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:45:56 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:46:41 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:47:27 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:47:47 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 12:57:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\edit-scorecard.php 29
ERROR - 2016-04-10 12:57:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\edit-scorecard.php 29
ERROR - 2016-04-10 12:57:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\edit-scorecard.php 29
ERROR - 2016-04-10 13:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\edit-scorecard.php 29
ERROR - 2016-04-10 13:04:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\edit-scorecard.php 29
ERROR - 2016-04-10 13:13:51 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 13:16:09 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 13:43:21 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-10 14:01:25 --> Severity: Warning --> Missing argument 1 for Score_card::edit_score_card(), called in C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php on line 153 and defined C:\MAMP\htdocs\horse\application\models\Admin\Score_card.php 104
ERROR - 2016-04-10 14:02:41 --> Severity: Warning --> Missing argument 1 for Score_card::edit_score_card(), called in C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php on line 153 and defined C:\MAMP\htdocs\horse\application\models\Admin\Score_card.php 104
ERROR - 2016-04-10 14:03:48 --> Severity: Warning --> Missing argument 1 for Score_card::edit_score_card(), called in C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php on line 153 and defined C:\MAMP\htdocs\horse\application\models\Admin\Score_card.php 104
ERROR - 2016-04-10 14:06:21 --> Severity: Warning --> Missing argument 1 for Score_card::edit_score_card(), called in C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php on line 153 and defined C:\MAMP\htdocs\horse\application\models\Admin\Score_card.php 104
ERROR - 2016-04-10 14:06:52 --> Severity: Warning --> Missing argument 1 for Score_card::edit_score_card(), called in C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php on line 153 and defined C:\MAMP\htdocs\horse\application\models\Admin\Score_card.php 104
ERROR - 2016-04-10 14:07:18 --> Severity: Warning --> Missing argument 1 for Score_card::edit_score_card(), called in C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php on line 153 and defined C:\MAMP\htdocs\horse\application\models\Admin\Score_card.php 104
ERROR - 2016-04-10 14:07:55 --> Severity: Warning --> Missing argument 1 for Score_card::edit_score_card(), called in C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php on line 153 and defined C:\MAMP\htdocs\horse\application\models\Admin\Score_card.php 104
ERROR - 2016-04-10 16:11:53 --> Query error: Column 'co_effecient' cannot be null - Invalid query: INSERT INTO `scorecard_sections_7` (`card_id`, `co_effecient`, `directive`, `divider`, `letters`, `order`, `points`, `test`) VALUES ('9',NULL,'a','y',NULL,'1',NULL,NULL)
ERROR - 2016-04-10 16:11:59 --> Query error: Column 'co_effecient' cannot be null - Invalid query: INSERT INTO `scorecard_sections_7` (`card_id`, `co_effecient`, `directive`, `divider`, `letters`, `order`, `points`, `test`) VALUES ('9',NULL,'aadfa','y',NULL,'1',NULL,NULL)
ERROR - 2016-04-10 16:17:17 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 16:17:20 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 16:17:22 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 16:17:26 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 16:22:45 --> Query error: Column 'letters' cannot be null - Invalid query: INSERT INTO `scorecard_sections_7` (`card_id`, `co_effecient`, `directive`, `divider`, `letters`, `order`, `points`, `test`) VALUES ('9','','','y',NULL,'1','','Dividers')
ERROR - 2016-04-10 18:16:02 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `scorecard_sections_7` (`card_id`, `co_effecient`, `directive`, `divider`, `letters`, `order`, `points`, `test`) VALUES ('9','0','a',Array,'a','1','0','Dividersss'), ('9','0','a',Array,'a','2','0','testssss'), ('9','0','a',Array,'a','3','0','a'), ('9','0','row',Array,'row','4','0','Divider'), ('9',NULL,NULL,Array,NULL,'5',NULL,'row')
ERROR - 2016-04-10 18:42:49 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 18:43:09 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 18:46:18 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 18:46:22 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 18:46:46 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 18:46:50 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 18:48:04 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 18:48:38 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 18:49:32 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 18:50:26 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 18:52:31 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 19:09:23 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-10 19:33:55 --> Severity: error --> Exception: Call to undefined method Widgets::select() C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 12
ERROR - 2016-04-10 19:34:03 --> Severity: error --> Exception: Call to undefined method Widgets::select() C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 12
ERROR - 2016-04-10 19:34:15 --> Severity: error --> Exception: Call to undefined method Widgets::select() C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 12
ERROR - 2016-04-10 19:34:31 --> Severity: Notice --> Undefined property: Dashboard::$Widgets C:\MAMP\htdocs\horse\application\controllers\Admin\Dashboard.php 33
ERROR - 2016-04-10 19:34:31 --> Severity: error --> Exception: Call to a member function newUsersThisMonth() on null C:\MAMP\htdocs\horse\application\controllers\Admin\Dashboard.php 33
ERROR - 2016-04-10 19:34:58 --> Severity: error --> Exception: Call to undefined method Widgets::select() C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 12
ERROR - 2016-04-10 19:35:11 --> Severity: error --> Exception: Call to undefined method Widgets::where() C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 13
ERROR - 2016-04-10 19:39:19 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\MAMP\htdocs\horse\application\controllers\Admin\Dashboard.php 46
ERROR - 2016-04-10 19:41:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') AND NOW()' at line 5 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users`
JOIN `users_groups` ON `users`.`id` = `users_groups`.`user_id`
WHERE `users_groups`.`group_id` = 2
AND `users`.`created_on` BETWEEN sDATE_SUB(NOW(), INTERVAL 30 DAY) AND NOW()
ERROR - 2016-04-10 19:42:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') AND NOW()' at line 5 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users`
JOIN `users_groups` ON `users`.`id` = `users_groups`.`user_id`
WHERE `users_groups`.`group_id` = 2
AND `users`.`created_on` BETWEEN sDATE_SUB(NOW(), INTERVAL 30 DAY) AND NOW()
ERROR - 2016-04-10 19:59:03 --> Query error: Table 'horse_trainer.paid_on' doesn't exist - Invalid query: SELECT *
FROM `paid_on` `>`
WHERE `2016-03-11` IS NULL
ERROR - 2016-04-10 19:59:52 --> Severity: Warning --> number_format() expects parameter 1 to be float, object given C:\MAMP\htdocs\horse\application\views\admin\admin-dashboard.php 14
ERROR - 2016-04-10 20:00:17 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\MAMP\htdocs\horse\application\controllers\Admin\Dashboard.php 37
ERROR - 2016-04-10 20:00:17 --> Severity: Warning --> number_format() expects parameter 1 to be float, object given C:\MAMP\htdocs\horse\application\views\admin\admin-dashboard.php 14
ERROR - 2016-04-10 20:00:21 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\MAMP\htdocs\horse\application\controllers\Admin\Dashboard.php 37
ERROR - 2016-04-10 20:00:21 --> Severity: Warning --> number_format() expects parameter 1 to be float, object given C:\MAMP\htdocs\horse\application\views\admin\admin-dashboard.php 14
ERROR - 2016-04-10 20:00:37 --> Severity: Warning --> number_format() expects parameter 1 to be float, object given C:\MAMP\htdocs\horse\application\views\admin\admin-dashboard.php 14
ERROR - 2016-04-10 20:00:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, object given C:\MAMP\htdocs\horse\application\views\admin\admin-dashboard.php 14
ERROR - 2016-04-10 20:16:56 --> Severity: Warning --> date() expects parameter 2 to be integer, object given C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:16:56 --> Severity: Notice --> Undefined property: mysqli::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:16:56 --> Severity: Warning --> date() expects parameter 2 to be integer, object given C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:16:56 --> Severity: Notice --> Undefined property: mysqli_result::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:16:56 --> Severity: Warning --> date() expects parameter 2 to be integer, array given C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:16:56 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:16:56 --> Severity: Warning --> date() expects parameter 2 to be integer, array given C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:16:56 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:16:56 --> Severity: Warning --> date() expects parameter 2 to be integer, array given C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:16:56 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:16:56 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:16:56 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:16:56 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Undefined property: mysqli::$Month C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Undefined property: mysqli::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Undefined property: mysqli_result::$Month C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Undefined property: mysqli_result::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Undefined property: mysqli::$Month C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Undefined property: mysqli::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Undefined property: mysqli_result::$Month C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Undefined property: mysqli_result::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:25 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:26 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 55
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Undefined property: mysqli::$Month C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Undefined property: mysqli::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Undefined property: mysqli_result::$Month C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Undefined property: mysqli_result::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:43 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:56 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:56 --> Severity: Notice --> Undefined property: stdClass::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:17:56 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:17:56 --> Severity: Notice --> Undefined property: stdClass::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:18:07 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:18:07 --> Severity: Notice --> Undefined property: stdClass::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:18:07 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:18:07 --> Severity: Notice --> Undefined property: stdClass::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:18:28 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:18:28 --> Severity: Notice --> Undefined property: stdClass::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:18:28 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:18:28 --> Severity: Notice --> Undefined property: stdClass::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:18:44 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:18:44 --> Severity: Notice --> Undefined property: stdClass::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:18:44 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:18:44 --> Severity: Notice --> Undefined property: stdClass::$amount C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 52
ERROR - 2016-04-10 20:18:57 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:18:57 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:19:18 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:19:18 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:19:29 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:19:29 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:20:28 --> Severity: error --> Exception: Non-static method DateTime::format() cannot be called statically C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:20:36 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:20:36 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 51
ERROR - 2016-04-10 20:21:13 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 50
ERROR - 2016-04-10 20:21:13 --> Severity: Notice --> A non well formed numeric value encountered C:\MAMP\htdocs\horse\application\models\Admin\Widgets.php 50
ERROR - 2016-04-10 21:15:52 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:15:52 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:15:52 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:15:52 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:15:52 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:15:52 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:15:52 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:15:52 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:04 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:04 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:04 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:04 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:04 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:04 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:04 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:04 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:16 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:16 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:16 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:16 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:16 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:16 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:16 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:16:16 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:18:55 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:18:55 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:18:55 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:18:55 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:18:55 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:18:55 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:18:55 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:18:55 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, class 'Format_data' does not have a method 'paid_on' C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:22:39 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' C:\MAMP\htdocs\horse\application\controllers\Admin\Sales.php 52
ERROR - 2016-04-10 21:22:42 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' C:\MAMP\htdocs\horse\application\controllers\Admin\Sales.php 52
ERROR - 2016-04-10 21:22:45 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' C:\MAMP\htdocs\horse\application\controllers\Admin\Sales.php 52
ERROR - 2016-04-10 21:23:08 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:08 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:08 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:08 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:09 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:09 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:09 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:09 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:24 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:24 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:24 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:24 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:24 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:24 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:24 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:23:24 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:25 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:25 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:25 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:25 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:25 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:25 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:25 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:25 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:24:57 --> Severity: Warning --> strstr() expects parameter 1 to be string, array given C:\MAMP\htdocs\horse\application\models\Grocery_crud_model.php 64
ERROR - 2016-04-10 21:24:58 --> Query error: Unknown column 'je8701ad4.Array' in 'field list' - Invalid query: SELECT `payments`.*, je8701ad4.Array AS se8701ad4
FROM `payments`
LEFT JOIN `users` as `je8701ad4` ON `je8701ad4`.`id` = `payments`.`user_id`
 LIMIT 10
ERROR - 2016-04-10 21:25:11 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:12 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:12 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:12 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:12 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:12 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:12 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:12 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:23 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:23 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:23 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:23 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:23 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:23 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:23 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:23 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:37 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:37 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:37 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:37 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:37 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:37 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:37 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:25:37 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:26:21 --> Query error: Unknown column 'je8701ad4.test' in 'field list' - Invalid query: SELECT `payments`.*, je8701ad4.test, last_name AS se8701ad4
FROM `payments`
LEFT JOIN `users` as `je8701ad4` ON `je8701ad4`.`id` = `payments`.`user_id`
 LIMIT 10
ERROR - 2016-04-10 21:28:11 --> Query error: Unknown column 'je8701ad4.test' in 'field list' - Invalid query: SELECT `payments`.*, je8701ad4.test, last_name AS se8701ad4
FROM `payments`
LEFT JOIN `users` as `je8701ad4` ON `je8701ad4`.`id` = `payments`.`user_id`
 LIMIT 10
ERROR - 2016-04-10 21:28:22 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:22 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:22 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:22 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:22 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:22 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:22 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:22 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:31 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:31 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:31 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:31 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:31 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:31 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:31 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:28:31 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:39 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:44 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:44 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:44 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:44 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:44 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:44 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:44 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 21:29:44 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 1797
ERROR - 2016-04-10 22:32:38 --> Geolocation => Invalid API key.
ERROR - 2016-04-10 22:45:07 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at C:\MAMP\htdocs\horse\application\controllers\Terms_of_service.php:88) C:\MAMP\htdocs\horse\system\libraries\Session\Session.php 140
ERROR - 2016-04-10 22:50:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:51:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:51:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:52:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:52:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:53:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:54:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:57:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:59:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:59:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:59:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 22:59:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:00:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:00:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:03:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:04:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:04:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:05:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:06:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:06:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:18:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:18:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:19:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:19:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:19:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:20:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:21:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:22:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:22:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:22:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:22:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:23:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:23:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:24:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:24:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:25:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:26:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:26:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:27:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:29:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:30:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:30:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:31:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:31:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:35:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:35:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:37:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:38:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:38:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:38:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:38:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:39:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:39:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:39:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:46:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-10 23:59:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
