<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-05 21:05:18 --> Geolocation => Invalid API key.
ERROR - 2016-04-05 22:18:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-04-05 22:18:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 10
ERROR - 2016-04-05 22:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 10
ERROR - 2016-04-05 22:19:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 10
ERROR - 2016-04-05 22:19:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 10
ERROR - 2016-04-05 22:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 10
ERROR - 2016-04-05 22:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:21:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:21:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:22:41 --> Severity: error --> Exception: Call to a member function getUsersVideos() on null C:\MAMP\htdocs\horse\application\controllers\Admin\Uploads.php 34
ERROR - 2016-04-05 22:22:44 --> Severity: error --> Exception: Call to a member function getUsersVideos() on null C:\MAMP\htdocs\horse\application\controllers\Admin\Uploads.php 34
ERROR - 2016-04-05 22:23:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-04-05 22:23:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:23:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:25:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:25:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:25:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:27:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:27:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:28:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:29:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:29:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:30:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:31:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:31:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:31:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:32:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 22:33:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\user-uploads.php 13
ERROR - 2016-04-05 23:14:31 --> Severity: Notice --> Undefined offset: 2 C:\MAMP\htdocs\horse\application\views\public-profile.php 51
ERROR - 2016-04-05 23:14:31 --> Severity: Notice --> Undefined offset: 2 C:\MAMP\htdocs\horse\application\views\public-profile.php 51
ERROR - 2016-04-05 23:14:32 --> Severity: Notice --> Undefined offset: 2 C:\MAMP\htdocs\horse\application\views\public-profile.php 51
ERROR - 2016-04-05 23:14:32 --> Severity: Notice --> Undefined offset: 2 C:\MAMP\htdocs\horse\application\views\public-profile.php 51
ERROR - 2016-04-05 23:14:32 --> Severity: Notice --> Undefined offset: 2 C:\MAMP\htdocs\horse\application\views\public-profile.php 51
ERROR - 2016-04-05 23:14:32 --> Severity: Notice --> Undefined offset: 2 C:\MAMP\htdocs\horse\application\views\public-profile.php 51
ERROR - 2016-04-05 23:14:32 --> Severity: Notice --> Undefined offset: 2 C:\MAMP\htdocs\horse\application\views\public-profile.php 51
ERROR - 2016-04-05 23:23:39 --> Severity: Notice --> Undefined variable: carousel C:\MAMP\htdocs\horse\application\views\public-profile.php 36
