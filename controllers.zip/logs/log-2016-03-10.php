<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-10 00:02:46 --> Severity: error --> Exception: Call to undefined method MY_Loader::modal() C:\MAMP\htdocs\horse\application\controllers\Error_404.php 31
ERROR - 2016-03-10 00:05:19 --> Severity: error --> Exception: Call to undefined method MY_Loader::modal() C:\MAMP\htdocs\horse\application\controllers\Error_404.php 31
ERROR - 2016-03-10 00:05:48 --> Severity: error --> Exception: Call to undefined method MY_Loader::modal() C:\MAMP\htdocs\horse\application\controllers\Error_404.php 31
ERROR - 2016-03-10 00:06:59 --> Severity: error --> Exception: Call to undefined method MY_Loader::modal() C:\MAMP\htdocs\horse\application\controllers\Error_404.php 31
ERROR - 2016-03-10 00:07:17 --> Severity: error --> Exception: C:\MAMP\htdocs\horse\application\models/admin/Support.php exists, but doesn't declare class Support C:\MAMP\htdocs\horse\system\core\Loader.php 336
ERROR - 2016-03-10 00:07:48 --> Severity: Notice --> Undefined property: Error_404::$isLoggedIn C:\MAMP\htdocs\horse\system\core\Model.php 77
ERROR - 2016-03-10 00:09:11 --> Severity: Notice --> Undefined property: Error_404::$isLoggedIn C:\MAMP\htdocs\horse\system\core\Model.php 77
ERROR - 2016-03-10 00:10:03 --> Severity: Notice --> Undefined property: Error_404::$isLoggedIn C:\MAMP\htdocs\horse\system\core\Model.php 77
ERROR - 2016-03-10 00:19:58 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 69
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 70
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 3
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 13
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 6
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 8
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 9
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 3
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 11
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-10 00:20:50 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 10
ERROR - 2016-03-10 00:22:44 --> 404 Page Not Found: 
ERROR - 2016-03-10 00:32:09 --> 404 Page Not Found: application/views/404-page.php
ERROR - 2016-03-10 00:32:23 --> 404 Page Not Found: application/views/404-page.php
ERROR - 2016-03-10 00:34:59 --> Severity: error --> Exception: Class 'MY_Exceptions' not found C:\MAMP\htdocs\horse\system\core\Common.php 196
ERROR - 2016-03-10 00:35:58 --> Severity: error --> Exception: Class 'MY_Exceptions' not found C:\MAMP\htdocs\horse\system\core\Common.php 196
ERROR - 2016-03-10 00:36:22 --> Severity: error --> Exception: Class 'MY_Exceptions' not found C:\MAMP\htdocs\horse\system\core\Common.php 196
ERROR - 2016-03-10 00:37:55 --> Severity: error --> Exception: Class 'MY_Exceptions' not found C:\MAMP\htdocs\horse\system\core\Common.php 196
ERROR - 2016-03-10 00:47:40 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 00:47:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 00:48:52 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 00:48:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 00:48:55 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 00:48:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:23:14 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:23:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:23:18 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:23:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:23:32 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:23:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:29:17 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\coaches.php 4
ERROR - 2016-03-10 01:29:29 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:29:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:30:03 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:30:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:30:13 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:31:02 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:31:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:31:09 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:31:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:31:17 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:31:17 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:31:34 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:31:34 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:31:57 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:31:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:32:04 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:32:04 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:34:12 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:34:51 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:34:51 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:35:51 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:35:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:36:32 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:36:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:39:10 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:39:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 01:41:31 --> Severity: error --> Exception: Call to undefined method Profiler::checkIfLoggedIn() C:\MAMP\htdocs\horse\application\controllers\Profiler.php 14
ERROR - 2016-03-10 01:45:15 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:45:15 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:46:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Action C:\MAMP\htdocs\horse\system\core\Loader.php 344
ERROR - 2016-03-10 01:47:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Action C:\MAMP\htdocs\horse\system\core\Loader.php 344
ERROR - 2016-03-10 01:49:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Action C:\MAMP\htdocs\horse\system\core\Loader.php 344
ERROR - 2016-03-10 01:52:12 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:52:13 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:53:58 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:53:58 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:53:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Action C:\MAMP\htdocs\horse\system\core\Loader.php 344
ERROR - 2016-03-10 01:54:04 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:54:04 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:54:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Action C:\MAMP\htdocs\horse\system\core\Loader.php 344
ERROR - 2016-03-10 01:55:26 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 01:55:26 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 02:00:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:00:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:00:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:00:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:00:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:01:03 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:01:03 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:01:03 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:01:03 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:01:03 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:01:55 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 02:01:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 02:01:57 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:01:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:01:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:01:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:01:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:02:08 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 02:02:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 02:02:13 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:02:13 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:02:13 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:02:13 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 02:02:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 20:37:22 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 20:38:34 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 20:38:35 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 20:38:40 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 20:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 20:39:35 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 20:39:35 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 20:56:52 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 20:56:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 20:56:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 20:56:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 20:56:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 20:56:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 20:57:05 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 20:57:05 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 20:58:19 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 20:58:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 20:58:25 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 20:58:25 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 20:58:25 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 20:58:25 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 20:58:25 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 20:59:03 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 20:59:03 --> Geolocation => Invalid API key.
ERROR - 2016-03-10 21:00:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 21:00:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 21:00:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 21:00:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 21:00:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 21:00:52 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 21:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-10 21:01:26 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 21:01:26 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 21:01:26 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 21:01:26 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
ERROR - 2016-03-10 21:01:26 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\MAMP\htdocs\horse\application\third_party\codeigniter-forensics\libraries\Profiler.php 544
