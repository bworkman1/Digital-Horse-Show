<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-06 12:40:56 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 12:41:23 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 12:41:23 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 12:52:52 --> Severity: Warning --> date() expects at least 1 parameter, 0 given C:\MAMP\htdocs\horse\application\views\score-cards\score-card.php 42
ERROR - 2016-03-06 14:34:48 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:34:48 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:38:58 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:38:58 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:40:05 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:40:05 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:40:19 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:40:19 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:41:11 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:41:11 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:41:51 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:41:51 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:48:53 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:48:53 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:49:25 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:49:25 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:49:33 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:49:33 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:52:03 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:52:03 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:52:20 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:52:20 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:53:42 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:53:42 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:55:06 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:55:06 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:56:22 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:56:22 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:57:15 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:57:15 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:58:10 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 14:58:10 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 15:00:55 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 15:00:55 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 15:00:58 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 15:00:58 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 15:01:13 --> Severity: Notice --> Undefined index: comp_name C:\MAMP\htdocs\horse\application\models\Uploads.php 214
ERROR - 2016-03-06 15:01:13 --> Severity: Notice --> Undefined index: comp_class C:\MAMP\htdocs\horse\application\models\Uploads.php 215
ERROR - 2016-03-06 15:01:13 --> Severity: Notice --> Undefined index: date C:\MAMP\htdocs\horse\application\models\Uploads.php 216
ERROR - 2016-03-06 15:01:13 --> Severity: Notice --> Undefined index: horse_name C:\MAMP\htdocs\horse\application\models\Uploads.php 217
ERROR - 2016-03-06 15:01:13 --> Query error: Column 'comp_name' cannot be null - Invalid query: INSERT INTO `video_uploads` (`user_id`, `size`, `path`, `ext`, `orig_name`, `client_name`, `encypt_name`, `comp_name`, `comp_class`, `date`, `horse_name`, `file_type`, `thumb`, `star_rating`, `location`, `cords`) VALUES ('1', 8551.58, '/uploads/administrator/2016/03/c3b38194aa44f94cacdfe8abad5a1460.mp4', '.mp4', 'PureWow_Presents_How_to_Clean_Silver_with_Ketchup.mp4', 'Shire', 'c3b38194aa44f94cacdfe8abad5a1460.mp4', NULL, NULL, NULL, NULL, 'video/mp4', 'uploads/administrator/2016/03/thumbs/c3b38194aa44f94cacdfe8abad5a1460.jpg', 0, '442 Mill Street, Utica, OH, United States', '40.2322599|-82.44428399999998')
ERROR - 2016-03-06 15:01:44 --> Severity: Notice --> Undefined index: comp_name C:\MAMP\htdocs\horse\application\models\Uploads.php 214
ERROR - 2016-03-06 15:01:44 --> Severity: Notice --> Undefined index: comp_class C:\MAMP\htdocs\horse\application\models\Uploads.php 215
ERROR - 2016-03-06 15:01:44 --> Severity: Notice --> Undefined index: date C:\MAMP\htdocs\horse\application\models\Uploads.php 216
ERROR - 2016-03-06 15:01:44 --> Severity: Notice --> Undefined index: horse_name C:\MAMP\htdocs\horse\application\models\Uploads.php 217
ERROR - 2016-03-06 15:01:44 --> Query error: Column 'comp_name' cannot be null - Invalid query: INSERT INTO `video_uploads` (`user_id`, `size`, `path`, `ext`, `orig_name`, `client_name`, `encypt_name`, `comp_name`, `comp_class`, `date`, `horse_name`, `file_type`, `thumb`, `star_rating`, `location`, `cords`) VALUES ('1', 8551.58, '/uploads/administrator/2016/03/fe27df43f67c359c4f9fc6df1f815a71.mp4', '.mp4', 'PureWow_Presents_How_to_Clean_Silver_with_Ketchup.mp4', 'Shire', 'fe27df43f67c359c4f9fc6df1f815a71.mp4', NULL, NULL, NULL, NULL, 'video/mp4', 'uploads/administrator/2016/03/thumbs/fe27df43f67c359c4f9fc6df1f815a71.jpg', 0, '442 Mill Street, Utica, OH, United States', '40.2322599|-82.44428399999998')
ERROR - 2016-03-06 15:01:53 --> Severity: Notice --> Undefined index: comp_name C:\MAMP\htdocs\horse\application\models\Uploads.php 214
ERROR - 2016-03-06 15:01:53 --> Severity: Notice --> Undefined index: comp_class C:\MAMP\htdocs\horse\application\models\Uploads.php 215
ERROR - 2016-03-06 15:01:53 --> Severity: Notice --> Undefined index: date C:\MAMP\htdocs\horse\application\models\Uploads.php 216
ERROR - 2016-03-06 15:01:53 --> Severity: Notice --> Undefined index: horse_name C:\MAMP\htdocs\horse\application\models\Uploads.php 217
ERROR - 2016-03-06 15:01:53 --> Query error: Column 'comp_name' cannot be null - Invalid query: INSERT INTO `video_uploads` (`user_id`, `size`, `path`, `ext`, `orig_name`, `client_name`, `encypt_name`, `comp_name`, `comp_class`, `date`, `horse_name`, `file_type`, `thumb`, `star_rating`, `location`, `cords`) VALUES ('1', 8551.58, '/uploads/administrator/2016/03/62cf4a7e311f5122185daa68d21228b5.mp4', '.mp4', 'PureWow_Presents_How_to_Clean_Silver_with_Ketchup.mp4', 'Shire', '62cf4a7e311f5122185daa68d21228b5.mp4', NULL, NULL, NULL, NULL, 'video/mp4', 'uploads/administrator/2016/03/thumbs/62cf4a7e311f5122185daa68d21228b5.jpg', 0, '442 Mill Street, Utica, OH, United States', '40.2322599|-82.44428399999998')
ERROR - 2016-03-06 15:02:16 --> Severity: Notice --> Undefined index: comp_name C:\MAMP\htdocs\horse\application\models\Uploads.php 214
ERROR - 2016-03-06 15:02:16 --> Severity: Notice --> Undefined index: comp_class C:\MAMP\htdocs\horse\application\models\Uploads.php 215
ERROR - 2016-03-06 15:02:16 --> Severity: Notice --> Undefined index: date C:\MAMP\htdocs\horse\application\models\Uploads.php 216
ERROR - 2016-03-06 15:02:16 --> Severity: Notice --> Undefined index: horse_name C:\MAMP\htdocs\horse\application\models\Uploads.php 217
ERROR - 2016-03-06 15:02:16 --> Query error: Column 'comp_name' cannot be null - Invalid query: INSERT INTO `video_uploads` (`user_id`, `size`, `path`, `ext`, `orig_name`, `client_name`, `encypt_name`, `comp_name`, `comp_class`, `date`, `horse_name`, `file_type`, `thumb`, `star_rating`, `location`, `cords`) VALUES ('1', 8551.58, '/uploads/administrator/2016/03/d3c90737ddea5eacb3d0c34dfc7ab93a.mp4', '.mp4', 'PureWow_Presents_How_to_Clean_Silver_with_Ketchup.mp4', 'Shire', 'd3c90737ddea5eacb3d0c34dfc7ab93a.mp4', NULL, NULL, NULL, NULL, 'video/mp4', 'uploads/administrator/2016/03/thumbs/d3c90737ddea5eacb3d0c34dfc7ab93a.jpg', 0, '442 Mill Street, Utica, OH, United States', '40.2322599|-82.44428399999998')
ERROR - 2016-03-06 15:05:39 --> Severity: Notice --> Undefined index: comp_name C:\MAMP\htdocs\horse\application\models\Uploads.php 214
ERROR - 2016-03-06 15:05:39 --> Severity: Notice --> Undefined index: comp_class C:\MAMP\htdocs\horse\application\models\Uploads.php 215
ERROR - 2016-03-06 15:05:39 --> Severity: Notice --> Undefined index: date C:\MAMP\htdocs\horse\application\models\Uploads.php 216
ERROR - 2016-03-06 15:05:39 --> Severity: Notice --> Undefined index: horse_name C:\MAMP\htdocs\horse\application\models\Uploads.php 217
ERROR - 2016-03-06 15:05:45 --> Severity: Notice --> Undefined index: comp_name C:\MAMP\htdocs\horse\application\models\Uploads.php 214
ERROR - 2016-03-06 15:05:45 --> Severity: Notice --> Undefined index: comp_class C:\MAMP\htdocs\horse\application\models\Uploads.php 215
ERROR - 2016-03-06 15:05:45 --> Severity: Notice --> Undefined index: date C:\MAMP\htdocs\horse\application\models\Uploads.php 216
ERROR - 2016-03-06 15:05:45 --> Severity: Notice --> Undefined index: horse_name C:\MAMP\htdocs\horse\application\models\Uploads.php 217
ERROR - 2016-03-06 15:33:07 --> Severity: error --> Exception: Call to undefined function form_clse() C:\MAMP\htdocs\horse\application\views\score-cards\score-card.php 373
ERROR - 2016-03-06 15:34:00 --> Severity: error --> Exception: Call to undefined function form_clse() C:\MAMP\htdocs\horse\application\views\score-cards\score-card.php 373
ERROR - 2016-03-06 15:35:07 --> 404 Page Not Found: Coach/Score_card/Add_grade
ERROR - 2016-03-06 15:35:12 --> 404 Page Not Found: Coach/Score_card/Add_grade
ERROR - 2016-03-06 15:41:16 --> 404 Page Not Found: Coach/Score_card/Add_grade
ERROR - 2016-03-06 15:41:32 --> 404 Page Not Found: Coach/Score_card/Add_grade
ERROR - 2016-03-06 15:41:58 --> 404 Page Not Found: Coach/Score_card/Add_grade
ERROR - 2016-03-06 15:42:08 --> 404 Page Not Found: Coach/Score_card/Add_grade
ERROR - 2016-03-06 15:42:30 --> 404 Page Not Found: Coach/Score_card/Add_grade
ERROR - 2016-03-06 19:48:10 --> Geolocation => Invalid API key.
ERROR - 2016-03-06 20:36:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = 'star_rating'
WHERE `id` = 79' at line 1 - Invalid query: UPDATE `video_uploads` SET 0 = 'star_rating'
WHERE `id` = 79
ERROR - 2016-03-06 21:18:07 --> 404 Page Not Found: 
ERROR - 2016-03-06 21:18:24 --> Severity: error --> Exception: Call to undefined method Grades::getScoreCard() C:\MAMP\htdocs\horse\application\controllers\User\Score_card.php 32
ERROR - 2016-03-06 21:22:30 --> Severity: error --> Exception: Call to undefined method Grades::getScoreCard() C:\MAMP\htdocs\horse\application\controllers\User\Score_card.php 32
ERROR - 2016-03-06 21:23:22 --> Severity: Notice --> Array to string conversion C:\MAMP\htdocs\horse\system\core\Loader.php 273
ERROR - 2016-03-06 21:23:22 --> Severity: error --> Exception: Unable to locate the model you have specified: View-score-card C:\MAMP\htdocs\horse\system\core\Loader.php 344
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 7
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 7
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 8
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 8
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 8
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 8
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 13
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 13
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 13
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 13
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 14
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 14
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 14
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 14
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 10
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 10
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 31
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 31
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 37
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 37
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 43
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 43
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 50
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 50
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 56
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 56
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Undefined variable: video C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 56
ERROR - 2016-03-06 21:24:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 56
ERROR - 2016-03-06 21:27:47 --> Query error: Table 'horse_trainer.scores' doesn't exist - Invalid query: SELECT *
FROM `scores`
WHERE `coach_id` = '1'
AND `video_id` = 79
ERROR - 2016-03-06 21:27:51 --> Query error: Table 'horse_trainer.scores' doesn't exist - Invalid query: SELECT *
FROM `scores`
WHERE `coach_id` = '1'
AND `video_id` = 79
ERROR - 2016-03-06 21:38:42 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 87
ERROR - 2016-03-06 21:39:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 88
ERROR - 2016-03-06 21:39:33 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\score-cards\view-score-card.php 88
ERROR - 2016-03-06 21:40:03 --> Query error: Table 'horse_trainer.scorings' doesn't exist - Invalid query: SELECT *
FROM `scorings`
WHERE `coach_id` = '1'
AND `video_id` = 110
ERROR - 2016-03-06 21:40:50 --> Query error: Table 'horse_trainer.scorings' doesn't exist - Invalid query: SELECT *
FROM `scorings`
WHERE `coach_id` = '1'
AND `video_id` = 110
