<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-09 21:08:53 --> Severity: Error --> Class 'CI_Model' not found C:\MAMP\htdocs\horse\application\controllers\User\Search.php 3
ERROR - 2016-03-09 21:09:55 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:09:56 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:09:57 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:10:07 --> 404 Page Not Found: 
ERROR - 2016-03-09 21:11:00 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:11:00 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:11:10 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:11:11 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:12:55 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:12:55 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:13:08 --> Severity: Error --> Class 'CI_Model' not found C:\MAMP\htdocs\horse\application\controllers\User\Search.php 3
ERROR - 2016-03-09 21:20:27 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:20:27 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:30:10 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:30:11 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:33:30 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:33:30 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 21:40:44 --> Query error: Column 'user_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `scoring`
JOIN `video_uploads` ON `scoring`.`video_id` = `video_uploads`.`id`
WHERE `user_id` = '2'
ERROR - 2016-03-09 21:41:38 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-09 21:41:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-09 21:41:38 --> Severity: Notice --> Undefined property: stdClass::$comments C:\MAMP\htdocs\horse\application\views\users\my-videos.php 72
ERROR - 2016-03-09 21:41:38 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\my-videos.php 95
ERROR - 2016-03-09 21:42:09 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-09 21:42:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-09 21:42:09 --> Severity: Notice --> Undefined property: stdClass::$comments C:\MAMP\htdocs\horse\application\views\users\my-videos.php 72
ERROR - 2016-03-09 21:44:20 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ';' C:\MAMP\htdocs\horse\application\models\User_videos.php 102
ERROR - 2016-03-09 21:44:30 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-09 21:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-09 21:44:44 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-09 21:44:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-09 22:00:28 --> 404 Page Not Found: 
ERROR - 2016-03-09 22:00:32 --> 404 Page Not Found: 
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 69
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 70
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 3
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 13
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 6
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 8
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 9
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 3
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 11
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-09 22:06:13 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 10
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 69
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 70
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 3
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 13
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 6
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 8
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 9
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 3
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 11
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-09 22:06:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 10
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 69
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 70
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 3
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 13
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 6
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 8
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 9
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 3
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 11
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-09 22:06:47 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 10
ERROR - 2016-03-09 22:06:55 --> 404 Page Not Found: User/My_uploads/Viewa
ERROR - 2016-03-09 22:07:39 --> Severity: Notice --> Undefined variable: data C:\MAMP\htdocs\horse\application\controllers\Error_404.php 15
ERROR - 2016-03-09 22:18:33 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 22:18:33 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 22:24:24 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 22:24:24 --> Geolocation => Invalid API key.
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 69
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 70
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 3
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 13
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 6
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 8
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 9
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 3
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 11
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-09 22:41:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 10
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 69
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 70
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 3
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 13
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 6
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 8
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 9
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 3
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 11
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-09 22:54:21 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 10
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 69
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 70
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 3
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 13
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 6
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 8
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 9
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 3
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 11
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-09 22:54:30 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 10
ERROR - 2016-03-09 22:58:54 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\MAMP\htdocs\horse\application\views\404-page.php 45
ERROR - 2016-03-09 22:59:29 --> Severity: Notice --> Use of undefined constant _SERVER - assumed '_SERVER' C:\MAMP\htdocs\horse\application\views\404-page.php 45
ERROR - 2016-03-09 22:59:29 --> Severity: Warning --> Illegal string offset 'HTTP_REFERER' C:\MAMP\htdocs\horse\application\views\404-page.php 45
ERROR - 2016-03-09 22:59:57 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\MAMP\htdocs\horse\application\views\404-page.php 45
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 69
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 70
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\controllers\User\My_uploads.php 72
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 3
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 13
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 14
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 19
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\view-video.php 20
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 6
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 8
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 9
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-details-card.php 23
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 3
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 11
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-09 23:04:03 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 10
ERROR - 2016-03-09 23:23:44 --> Severity: error --> Exception: syntax error, unexpected ';' C:\MAMP\htdocs\horse\application\controllers\Error_404.php 33
ERROR - 2016-03-09 23:23:48 --> Severity: error --> Exception: syntax error, unexpected ';' C:\MAMP\htdocs\horse\application\controllers\Error_404.php 33
