<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-11 00:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-11 00:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\coaches.php 11
ERROR - 2016-04-11 00:06:09 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:06:48 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:06:54 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:07:01 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:07:06 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:07:15 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:07:43 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:07:47 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:08:40 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:08:44 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:09:05 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:09:30 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:09:40 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:09:55 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:10:00 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:10:38 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:10:42 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:11:07 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
ERROR - 2016-04-11 00:11:13 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 4
