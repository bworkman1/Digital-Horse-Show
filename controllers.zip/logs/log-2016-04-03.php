<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-03 02:25:58 --> Severity: Warning --> Missing argument 1 for Score_card::buildScoreCard(), called in C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php on line 77 and defined C:\MAMP\htdocs\horse\application\models\Admin\Score_card.php 33
ERROR - 2016-04-03 02:26:19 --> Severity: Warning --> Missing argument 1 for Score_card::buildScoreCard(), called in C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php on line 77 and defined C:\MAMP\htdocs\horse\application\models\Admin\Score_card.php 33
ERROR - 2016-04-03 02:35:15 --> Severity: Warning --> Missing argument 1 for Score_card::buildScoreCard(), called in C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php on line 77 and defined C:\MAMP\htdocs\horse\application\models\Admin\Score_card.php 33
ERROR - 2016-04-03 02:42:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0, 1, 2, 3, 4) VALUES (Array, Array, Array, Array, Array)' at line 1 - Invalid query: INSERT INTO `scorecard_sections_7` (0, 1, 2, 3, 4) VALUES (Array, Array, Array, Array, Array)
ERROR - 2016-04-03 03:59:42 --> Severity: error --> Exception: Call to undefined method Score_card::load_view() C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php 63
ERROR - 2016-04-03 03:59:46 --> Severity: error --> Exception: Call to undefined method Score_card::load_view() C:\MAMP\htdocs\horse\application\controllers\Admin\Scorecards.php 63
ERROR - 2016-04-03 04:08:01 --> Query error: Table 'horse_trainer.score_cardss' doesn't exist - Invalid query: SELECT *
FROM `score_cardss`
WHERE `id` = 'detail'
ERROR - 2016-04-03 04:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 31
ERROR - 2016-04-03 04:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 31
ERROR - 2016-04-03 17:08:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\score-cards.php 19
ERROR - 2016-04-03 17:08:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\score-cards.php 19
ERROR - 2016-04-03 17:09:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\score-cards.php 19
ERROR - 2016-04-03 17:09:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\score-cards.php 19
ERROR - 2016-04-03 17:10:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\score-cards.php 19
ERROR - 2016-04-03 17:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\score-cards.php 19
ERROR - 2016-04-03 17:11:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\score-cards.php 19
ERROR - 2016-04-03 17:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\score-cards.php 19
ERROR - 2016-04-03 17:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\score-cards.php 19
ERROR - 2016-04-03 17:13:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\score-cards.php 19
ERROR - 2016-04-03 17:14:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\admin\score-cards.php 19
ERROR - 2016-04-03 19:23:13 --> Severity: Warning --> array_keys() expects parameter 1 to be array, boolean given C:\MAMP\htdocs\horse\system\database\DB_query_builder.php 1520
ERROR - 2016-04-03 19:23:13 --> Severity: Warning --> sort() expects parameter 1 to be array, null given C:\MAMP\htdocs\horse\system\database\DB_query_builder.php 1521
ERROR - 2016-04-03 19:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\system\database\DB_query_builder.php 1549
ERROR - 2016-04-03 19:23:19 --> Severity: Warning --> array_keys() expects parameter 1 to be array, boolean given C:\MAMP\htdocs\horse\system\database\DB_query_builder.php 1520
ERROR - 2016-04-03 19:23:19 --> Severity: Warning --> sort() expects parameter 1 to be array, null given C:\MAMP\htdocs\horse\system\database\DB_query_builder.php 1521
ERROR - 2016-04-03 19:23:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\system\database\DB_query_builder.php 1549
ERROR - 2016-04-03 19:25:10 --> Severity: Warning --> array_keys() expects parameter 1 to be array, boolean given C:\MAMP\htdocs\horse\system\database\DB_query_builder.php 1520
ERROR - 2016-04-03 19:25:10 --> Severity: Warning --> sort() expects parameter 1 to be array, null given C:\MAMP\htdocs\horse\system\database\DB_query_builder.php 1521
ERROR - 2016-04-03 19:25:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\system\database\DB_query_builder.php 1549
ERROR - 2016-04-03 16:53:02 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\MAMP\htdocs\horse\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2016-04-03 16:53:02 --> Unable to connect to the database
ERROR - 2016-04-03 16:55:34 --> Geolocation => Invalid API key.
ERROR - 2016-04-03 16:57:44 --> Query error: Unknown column 'payments.coach_id' in 'on clause' - Invalid query: SELECT *
FROM `payments`
JOIN `users` ON `payments`.`coach_id` = `users`.`id`
WHERE `payments`.`user_id` = '1'
ORDER BY `payments`.`id` DESC
ERROR - 2016-04-03 16:57:56 --> Query error: Unknown column 'payments.coach_id' in 'on clause' - Invalid query: SELECT *
FROM `payments`
JOIN `users` ON `payments`.`coach_id` = `users`.`id`
WHERE `payments`.`user_id` = '1'
ORDER BY `payments`.`id` DESC
ERROR - 2016-04-03 16:58:24 --> Severity: error --> Exception: The table name does not exist. Please check you database and try again. C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 4945
ERROR - 2016-04-03 16:58:27 --> Severity: error --> Exception: The table name does not exist. Please check you database and try again. C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 4945
ERROR - 2016-04-03 16:58:45 --> Severity: error --> Exception: The table name does not exist. Please check you database and try again. C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 4945
ERROR - 2016-04-03 16:58:56 --> Severity: error --> Exception: The table name does not exist. Please check you database and try again. C:\MAMP\htdocs\horse\application\libraries\Grocery_CRUD.php 4945
ERROR - 2016-04-03 17:09:21 --> Query error: Unknown column 'select' in 'group statement' - Invalid query: SELECT *
FROM `score_cards`
GROUP BY `select`, `child_of`
ERROR - 2016-04-03 19:08:04 --> Query error: Unknown column 'orders' in 'order clause' - Invalid query: SELECT *
FROM `scorecard_sections_7`
WHERE `card_id` = 7
ORDER BY `orders`
ERROR - 2016-04-03 19:11:47 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:16:30 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:17:00 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:17:29 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:20:24 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:26:02 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:27:59 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:29:13 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:31:07 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:31:20 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:31:50 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:32:41 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:33:31 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:33:36 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:34:35 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:34:54 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:35:30 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:35:42 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:35:52 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:38:27 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:38:48 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:40:09 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:40:50 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:41:12 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:41:21 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:41:27 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:41:52 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:42:13 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:42:24 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:43:28 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:43:39 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:43:48 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:43:58 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:44:06 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:44:40 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:44:55 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:45:01 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:46:30 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:46:44 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:47:24 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:47:42 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:51:28 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:52:50 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:54:10 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:54:23 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:54:44 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 19:54:58 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:00:13 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:01:24 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:01:38 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:02:15 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:10:39 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:11:58 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:12:20 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:12:56 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:13:01 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:13:21 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:14:03 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:23:38 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:26:05 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:26:21 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:26:40 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 20:59:45 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:00:00 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:09:31 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:10:12 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:11:51 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:12:07 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:12:31 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:13:39 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:15:04 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:15:30 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:16:58 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:18:26 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:19:39 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:20:26 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:20:47 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:21:06 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:22:08 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:24:00 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:26:00 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:26:12 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:26:26 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:27:15 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:28:50 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:29:55 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:30:08 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:30:44 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:32:20 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:32:41 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:33:40 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:33:56 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:35:30 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:37:18 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:37:55 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:38:28 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:39:48 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:40:22 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:40:54 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:41:29 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:44:19 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:44:48 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:46:17 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:46:34 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:51:04 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:52:33 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:52:45 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 21:58:52 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:00:25 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:01:10 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:01:17 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:01:45 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:01:49 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:02:13 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:02:49 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:02:53 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:03:24 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:04:04 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:04:13 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:04:20 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:05:17 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:05:55 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:05:59 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:06:13 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:07:11 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:07:53 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
ERROR - 2016-04-03 22:08:21 --> Severity: Warning --> Creating default object from empty value C:\MAMP\htdocs\horse\application\views\score-cards\cards\scorecard-sections-7.php 7
