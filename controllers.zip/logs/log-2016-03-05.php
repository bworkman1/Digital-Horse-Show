ERROR - 2016-03-05 16:53:04 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 16:53:04 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 16:55:01 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 16:55:01 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 16:55:10 --> Severity: Warning --> Illegal string offset 'system_path' C:\MAMP\htdocs\horse\application\models\Uploads.php 99
ERROR - 2016-03-05 16:57:09 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 16:57:09 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 16:58:18 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 16:58:18 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:00:43 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:00:43 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:02:18 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:02:18 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:09:49 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:09:49 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:11:19 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:11:19 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:16:36 --> 404 Page Not Found: 
ERROR - 2016-03-05 17:16:46 --> 404 Page Not Found: 
ERROR - 2016-03-05 17:18:14 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:18:14 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:19:34 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:19:44 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:19:44 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:20:54 --> Severity: Notice --> Undefined variable: emails_on C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 94
ERROR - 2016-03-05 17:20:54 --> Severity: Notice --> Undefined variable: newsletter C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 95
ERROR - 2016-03-05 17:20:54 --> Severity: Notice --> Undefined variable: email_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 96
ERROR - 2016-03-05 17:20:54 --> Severity: Notice --> Undefined variable: profile_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 97
ERROR - 2016-03-05 17:22:50 --> Severity: Notice --> Undefined variable: emails_on C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 94
ERROR - 2016-03-05 17:22:50 --> Severity: Notice --> Undefined variable: newsletter C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 95
ERROR - 2016-03-05 17:22:50 --> Severity: Notice --> Undefined variable: email_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 96
ERROR - 2016-03-05 17:22:50 --> Severity: Notice --> Undefined variable: profile_public C:\MAMP\htdocs\horse\application\controllers\User\My_profile.php 97
ERROR - 2016-03-05 17:29:47 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\MAMP\htdocs\horse\application\views\users\my-videos.php 91
ERROR - 2016-03-05 17:33:30 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:33:30 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 17:39:54 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\users-dashboard.php 31
ERROR - 2016-03-05 17:40:56 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\users-dashboard.php 31
ERROR - 2016-03-05 18:32:51 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 18:32:51 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 18:35:16 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' C:\MAMP\htdocs\horse\application\views\users\users-dashboard.php 37
ERROR - 2016-03-05 18:38:01 --> Query error: Not unique table/alias: 'upload_comments' - Invalid query: SELECT *
FROM `video_uploads`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `users` ON `users`.`id` = `upload_comments`.`user_id`
WHERE `video_uploads`.`user_id` = '2'
AND `upload_comments`.`user_id` != '2'
 LIMIT 10
ERROR - 2016-03-05 18:39:36 --> Query error: Not unique table/alias: 'upload_comments' - Invalid query: SELECT *
FROM `video_uploads`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `users` as `user` ON `users`.`id` = `upload_comments`.`user_id`
WHERE `video_uploads`.`user_id` = '2'
AND `upload_comments`.`user_id` != '2'
 LIMIT 10
ERROR - 2016-03-05 18:40:59 --> Query error: Unknown column 'upload_comments.comment' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `users`.`user_image`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:41:50 --> Query error: Unknown column 'upload_comments.comment' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `users`.`user_image`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:42:07 --> Query error: Unknown column 'upload_comments.comment' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `users`.`user_image`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:42:39 --> Query error: Unknown column 'upload_comments.comment' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `users`.`user_image`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:42:50 --> Query error: Unknown column 'upload_comments.comment' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:43:00 --> Query error: Unknown column 'comment' in 'field list' - Invalid query: SELECT `comment`, `video_id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:43:21 --> Query error: Unknown column 'comment' in 'field list' - Invalid query: SELECT `comment`, `video_id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:43:54 --> Query error: Unknown column 'upload_comments.comment' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:44:15 --> Query error: Unknown column 'video_uploads.id' in 'on clause' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:46:51 --> Query error: Unknown column 'video_uploads.id' in 'on clause' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:48:45 --> Query error: Unknown column 'video_uploads.id' in 'on clause' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:48:56 --> Query error: Unknown column 'video_uploads.id' in 'on clause' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:49:12 --> Query error: Unknown column 'video_uploads.id' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `video_uploads`.`id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:49:31 --> Query error: Unknown column 'video_uploads.id' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `video_uploads`.`id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:49:45 --> Query error: Unknown column 'video_uploads.id' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `video_uploads`.`id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:50:16 --> Query error: Unknown column 'video_uploads.id' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `video_uploads`.`id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 18:50:19 --> Query error: Unknown column 'video_uploads.id' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `video_uploads`.`id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '2'
ERROR - 2016-03-05 21:45:58 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 21:46:00 --> Query error: Unknown column 'video_uploads.id' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `video_uploads`.`id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '1'
ERROR - 2016-03-05 21:46:11 --> Query error: Unknown column 'video_uploads.id' in 'field list' - Invalid query: SELECT `upload_comments`.`comment`, `upload_comments`.`video_id`, `video_uploads`.`id`, `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '1'
ERROR - 2016-03-05 21:46:23 --> Query error: Unknown column 'video_uploads.id' in 'on clause' - Invalid query: SELECT `users_groups`.`group_id` as `id`, `groups`.`name`, `groups`.`description`
FROM `users_groups`
JOIN `upload_comments` ON `upload_comments`.`video_id` = `video_uploads`.`id`
JOIN `groups` ON `users_groups`.`group_id`=`groups`.`id`
WHERE `users_groups`.`user_id` = '1'
ERROR - 2016-03-05 21:47:10 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 21:51:16 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' C:\MAMP\htdocs\horse\application\views\users\users-dashboard.php 39
ERROR - 2016-03-05 22:26:55 --> Severity: Notice --> Undefined variable: recentComments C:\MAMP\htdocs\horse\application\views\ui-elements\recent-comments.php 3
ERROR - 2016-03-05 22:26:55 --> Severity: Notice --> Undefined variable: recentComments C:\MAMP\htdocs\horse\application\views\ui-elements\recent-comments.php 6
ERROR - 2016-03-05 22:28:52 --> Severity: Notice --> Undefined variable: recentCommentss C:\MAMP\htdocs\horse\application\views\ui-elements\recent-comments.php 7
ERROR - 2016-03-05 22:32:52 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:32:53 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:33:52 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:33:52 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:34:27 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:34:27 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:34:37 --> Severity: Notice --> Undefined index: cords C:\MAMP\htdocs\horse\application\models\Uploads.php 218
ERROR - 2016-03-05 22:35:36 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:35:36 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:35:50 --> Severity: Notice --> Undefined index: cords C:\MAMP\htdocs\horse\application\models\Uploads.php 218
ERROR - 2016-03-05 22:36:11 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:36:11 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:36:25 --> Severity: Notice --> Undefined index: cords C:\MAMP\htdocs\horse\application\models\Uploads.php 218
ERROR - 2016-03-05 22:36:36 --> Severity: Notice --> Undefined index: cords C:\MAMP\htdocs\horse\application\models\Uploads.php 218
ERROR - 2016-03-05 22:36:40 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:36:40 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:37:45 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:37:46 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 22:58:45 --> Query error: Duplicate entry 'brian.workman@rocketmail.com' for key 'email' - Invalid query: INSERT INTO `users` (`first_name`, `last_name`, `phone`, `username`, `password`, `email`, `ip_address`, `created_on`, `active`) VALUES ('Coach', 'Karl', '7406611411', 'coachk', '$2y$08$QIJPf8oevTr0.DnsZy/PQ.1Ru.7AEQCA1rqNDkClTmMdKFbAJVbau', 'brian.workman@rocketmail.com', '127.0.0.1', 1457236725, 1)
ERROR - 2016-03-05 23:01:14 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 23:01:43 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 23:01:43 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 23:07:41 --> 404 Page Not Found: 
ERROR - 2016-03-05 23:29:03 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *
FROM `video_uploads`
JOIN `users` ON `users`.`id` = `video_uploads`.`user_id`
WHERE `id` = 108
ERROR - 2016-03-05 23:30:56 --> 404 Page Not Found: 
ERROR - 2016-03-05 23:31:05 --> 404 Page Not Found: 
ERROR - 2016-03-05 23:37:11 --> Severity: Notice --> Undefined property: stdClass::$video_id C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 24
ERROR - 2016-03-05 23:37:33 --> Severity: Notice --> Undefined property: stdClass::$user C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 25
ERROR - 2016-03-05 23:38:22 --> Severity: Notice --> Undefined property: stdClass::$user C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 24
ERROR - 2016-03-05 23:38:56 --> Severity: Notice --> Undefined property: stdClass::$user C:\MAMP\htdocs\horse\application\views\ui-elements\video-options.php 24
ERROR - 2016-03-05 23:39:58 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:39:58 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:39:58 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:39:58 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:40:20 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:40:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:40:20 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:40:20 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:40:31 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:40:31 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:40:31 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:40:31 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:41:23 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:41:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:41:23 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:41:23 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:42:09 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:42:09 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:42:09 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:42:09 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:43:02 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:43:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:43:02 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:43:02 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:43:48 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:43:48 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 4
ERROR - 2016-03-05 23:43:48 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:43:49 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\ui-elements\user-profile-card.php 8
ERROR - 2016-03-05 23:47:53 --> Geolocation => Invalid API key.
ERROR - 2016-03-05 23:47:53 --> Geolocation => Invalid API key.
