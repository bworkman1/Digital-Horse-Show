<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-19 11:12:54 --> Geolocation => Invalid API key.
ERROR - 2016-03-19 11:13:39 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-19 11:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-19 11:14:04 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-19 11:14:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-19 11:15:05 --> Severity: Notice --> Undefined variable: options C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-19 11:15:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\my-videos.php 10
ERROR - 2016-03-19 11:15:21 --> Geolocation => Invalid API key.
ERROR - 2016-03-19 11:15:21 --> Geolocation => Invalid API key.
ERROR - 2016-03-19 12:04:10 --> Severity: Notice --> Undefined property: Profile::$admin_users C:\MAMP\htdocs\horse\application\controllers\Profile.php 25
ERROR - 2016-03-19 12:04:10 --> Severity: error --> Exception: Call to a member function searchUser() on null C:\MAMP\htdocs\horse\application\controllers\Profile.php 25
ERROR - 2016-03-19 12:04:11 --> Severity: Notice --> Undefined property: Profile::$admin_users C:\MAMP\htdocs\horse\application\controllers\Profile.php 25
ERROR - 2016-03-19 12:04:11 --> Severity: error --> Exception: Call to a member function searchUser() on null C:\MAMP\htdocs\horse\application\controllers\Profile.php 25
ERROR - 2016-03-19 12:04:11 --> Severity: Notice --> Undefined property: Profile::$admin_users C:\MAMP\htdocs\horse\application\controllers\Profile.php 25
ERROR - 2016-03-19 12:04:11 --> Severity: error --> Exception: Call to a member function searchUser() on null C:\MAMP\htdocs\horse\application\controllers\Profile.php 25
ERROR - 2016-03-19 12:04:25 --> Severity: Notice --> Undefined property: Profile::$admin_users C:\MAMP\htdocs\horse\application\controllers\Profile.php 25
ERROR - 2016-03-19 12:04:25 --> Severity: error --> Exception: Call to a member function searchUser() on null C:\MAMP\htdocs\horse\application\controllers\Profile.php 25
ERROR - 2016-03-19 12:04:58 --> Query error: Unknown column 'public' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `first_name` LIKE '%brianss%' ESCAPE '!'
AND  `last_name` LIKE '%brianss%' ESCAPE '!'
AND `public` = 'yes'
ERROR - 2016-03-19 12:05:48 --> Query error: Unknown column 'public' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `first_name` LIKE '%brians%' ESCAPE '!'
AND  `last_name` LIKE '%brians%' ESCAPE '!'
AND `public` = 'yes'
ERROR - 2016-03-19 12:05:48 --> Query error: Unknown column 'public' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `first_name` LIKE '%brian%' ESCAPE '!'
AND  `last_name` LIKE '%brian%' ESCAPE '!'
AND `public` = 'yes'
ERROR - 2016-03-19 12:42:19 --> Query error: Unknown column 'first_names' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `first_names` LIKE '%Bria%' ESCAPE '!'
AND  `last_name` LIKE '%Bria%' ESCAPE '!'
AND `profile_public` = 'yes'
ERROR - 2016-03-19 12:42:27 --> Query error: Unknown column 'first_names' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `first_names` LIKE '%Brian%' ESCAPE '!'
AND  `last_name` LIKE '%Brian%' ESCAPE '!'
AND `profile_public` = 'yes'
ERROR - 2016-03-19 13:08:15 --> 404 Page Not Found: 
ERROR - 2016-03-19 13:08:58 --> 404 Page Not Found: 
ERROR - 2016-03-19 13:10:01 --> 404 Page Not Found: 
ERROR - 2016-03-19 13:13:52 --> Severity: Notice --> Undefined property: Profile::$admin_users C:\MAMP\htdocs\horse\application\controllers\Profile.php 42
ERROR - 2016-03-19 13:13:52 --> Severity: error --> Exception: Call to a member function getUserByProfileName() on null C:\MAMP\htdocs\horse\application\controllers\Profile.php 42
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 5
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 5
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 8
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 8
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 11
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 11
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 14
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 14
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 17
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 17
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 23
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 23
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 27
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 27
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 33
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 33
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 33
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 33
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 34
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 34
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 35
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 35
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: videos C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 51
ERROR - 2016-03-19 13:14:17 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 62
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 5
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 5
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 8
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 8
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 11
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 11
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 14
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 14
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 17
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 17
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 23
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 23
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 27
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 27
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 33
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 33
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 33
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 33
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 34
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 34
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: user C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 35
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Trying to get property of non-object C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 35
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: videos C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 51
ERROR - 2016-03-19 17:03:11 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 62
ERROR - 2016-03-19 17:03:49 --> Query error: Table 'horse_trainer.userss' doesn't exist - Invalid query: SELECT *
FROM `userss`
WHERE `profile_name` = 'bworkman'
ERROR - 2016-03-19 17:04:43 --> Query error: Table 'horse_trainer.userss' doesn't exist - Invalid query: SELECT *
FROM `userss`
WHERE `profile_name` = 'bworkman'
ERROR - 2016-03-19 17:04:50 --> Severity: Notice --> Undefined variable: videos C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 51
ERROR - 2016-03-19 17:04:50 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 62
ERROR - 2016-03-19 17:18:24 --> Severity: Notice --> Undefined variable: videos C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 51
ERROR - 2016-03-19 17:18:24 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 62
ERROR - 2016-03-19 17:18:54 --> Severity: Notice --> Undefined variable: videos C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 49
ERROR - 2016-03-19 17:18:54 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 60
ERROR - 2016-03-19 17:19:05 --> Severity: Notice --> Undefined variable: videos C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 49
ERROR - 2016-03-19 17:19:05 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 60
ERROR - 2016-03-19 17:19:36 --> Severity: Notice --> Undefined variable: videos C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 49
ERROR - 2016-03-19 17:19:36 --> Severity: Notice --> Undefined variable: page_name C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 60
ERROR - 2016-03-19 17:19:53 --> Severity: Notice --> Undefined variable: videos C:\MAMP\htdocs\horse\application\views\users\user-profile-page.php 49
ERROR - 2016-03-19 17:32:39 --> Geolocation => Invalid API key.
ERROR - 2016-03-19 18:08:26 --> Severity: Notice --> Undefined property: Payment::$coaches C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 32
ERROR - 2016-03-19 18:08:26 --> Severity: error --> Exception: Call to a member function getAvailableCoaches() on null C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 32
ERROR - 2016-03-19 18:08:48 --> Severity: Notice --> Undefined property: Payment::$coaches C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 32
ERROR - 2016-03-19 18:08:48 --> Severity: error --> Exception: Call to a member function getAvailableCoaches() on null C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 32
ERROR - 2016-03-19 18:09:01 --> Severity: Notice --> Undefined property: Payment::$coaches C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 32
ERROR - 2016-03-19 18:09:01 --> Severity: error --> Exception: Call to a member function getAvailableCoaches() on null C:\MAMP\htdocs\horse\application\controllers\User\Payment.php 32
ERROR - 2016-03-19 18:21:40 --> Severity: Notice --> Undefined variable: coachs C:\MAMP\htdocs\horse\application\views\users\payment-page.php 160
ERROR - 2016-03-19 18:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\MAMP\htdocs\horse\application\views\users\payment-page.php 160
ERROR - 2016-03-19 18:46:24 --> Severity: Notice --> Undefined property: stdClass::$created C:\MAMP\htdocs\horse\application\views\users\payment-page.php 166
