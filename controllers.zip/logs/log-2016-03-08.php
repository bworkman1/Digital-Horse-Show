<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-08 20:59:52 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:07:29 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:14:32 --> 404 Page Not Found: 
ERROR - 2016-03-08 21:14:58 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:31:57 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:36:34 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:36:35 --> 404 Page Not Found: 
ERROR - 2016-03-08 21:36:35 --> 404 Page Not Found: 
ERROR - 2016-03-08 21:36:52 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:36:53 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:37:40 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:39:31 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:39:49 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:40:09 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:41:25 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:41:41 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:42:43 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:43:01 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:43:29 --> 404 Page Not Found: 
ERROR - 2016-03-08 21:43:35 --> 404 Page Not Found: 
ERROR - 2016-03-08 21:44:09 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:44:43 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:47:46 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:48:27 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:48:56 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 21:54:00 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\MAMP\htdocs\horse\application\controllers\User\Logout.php 18
ERROR - 2016-03-08 21:54:37 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\MAMP\htdocs\horse\application\controllers\User\Logout.php 18
ERROR - 2016-03-08 22:09:30 --> 404 Page Not Found: 
ERROR - 2016-03-08 22:10:18 --> 404 Page Not Found: 
ERROR - 2016-03-08 22:11:45 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:11:47 --> 404 Page Not Found: 
ERROR - 2016-03-08 22:27:05 --> Query error: Unknown column 's' in 'where clause' - Invalid query: SELECT *
FROM `scoring`
WHERE `s` = '2'
ERROR - 2016-03-08 22:27:23 --> Query error: Table 'horse_trainer.scorings' doesn't exist - Invalid query: SELECT *
FROM `scorings`
WHERE `video_id` = '2'
ERROR - 2016-03-08 22:28:37 --> 404 Page Not Found: 
ERROR - 2016-03-08 22:28:42 --> 404 Page Not Found: 
ERROR - 2016-03-08 22:30:32 --> 404 Page Not Found: 
ERROR - 2016-03-08 22:30:53 --> 404 Page Not Found: 
ERROR - 2016-03-08 22:30:57 --> 404 Page Not Found: 
ERROR - 2016-03-08 22:36:33 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:36:34 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:44:23 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:44:23 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:45:42 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:45:42 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:45:42 --> Severity: 4096 --> Object of class MY_Loader could not be converted to string C:\MAMP\htdocs\horse\application\views\users\upload-video.php 6
ERROR - 2016-03-08 22:45:57 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:45:57 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:47:54 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:47:54 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:48:20 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:48:21 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:48:29 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:48:29 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:49:56 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:49:57 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:51:53 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:51:53 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:52:55 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:52:55 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:53:44 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:53:44 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:54:28 --> Severity: Error --> Class 'CI_Model' not found C:\MAMP\htdocs\horse\application\controllers\User\Search.php 3
ERROR - 2016-03-08 22:54:30 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:54:31 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:55:41 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:55:41 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:56:14 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:56:14 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:56:47 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:56:47 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:57:59 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 22:57:59 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:00:12 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:00:12 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:01:05 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:01:06 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:01:22 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:01:22 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:01:53 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:01:54 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:08:07 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:08:07 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:09:26 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:09:26 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:09:41 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:09:59 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:10:00 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:10:16 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:11:31 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:11:31 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:11:32 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:12:45 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:12:45 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:12:46 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:13:40 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:13:40 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:13:41 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:14:15 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:14:15 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:14:16 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:14:37 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:14:37 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:14:38 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:14:49 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:14:50 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:14:50 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:15:16 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:15:16 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:15:16 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:15:35 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:15:35 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:15:36 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:16:23 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:16:23 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:16:24 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:16:43 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:16:43 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:16:44 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:17:33 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:17:33 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:17:33 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:17:39 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:17:39 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:17:40 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:02 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:02 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:02 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:02 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:02 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:03 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:03 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:03 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:03 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:03 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:03 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:03 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:03 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:18 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:18:19 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:18:19 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:18:31 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:19:48 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:19:48 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:19:49 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:21:41 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:21:41 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:21:46 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:21:46 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:21:59 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:21:59 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:22:01 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:22:11 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:22:11 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:22:11 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:24:18 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:24:18 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:24:18 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:25:37 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:25:38 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:25:38 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:26:55 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:26:55 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:26:56 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:27:50 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:27:50 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:27:51 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:27:57 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:27:58 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:28:12 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:28:12 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:28:12 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:28:13 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:28:14 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:28:14 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:28:36 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:28:37 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:28:52 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:28:52 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:28:59 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:30:18 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:30:18 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:30:19 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:30:24 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:30:24 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:30:24 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:30:30 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:30:30 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:30:31 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:30:36 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:30:36 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:30:36 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:30:56 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:30:56 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:31:45 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:31:45 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:32:00 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:32:24 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:32:24 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:32:24 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:33:10 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:33:10 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:33:11 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:33:56 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:33:56 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:33:57 --> 404 Page Not Found: 
ERROR - 2016-03-08 23:34:06 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:34:06 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:34:15 --> Severity: Error --> Class 'CI_Model' not found C:\MAMP\htdocs\horse\application\controllers\User\Search.php 3
ERROR - 2016-03-08 23:34:18 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:34:18 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:34:23 --> Severity: Error --> Class 'CI_Model' not found C:\MAMP\htdocs\horse\application\controllers\User\Search.php 3
ERROR - 2016-03-08 23:34:26 --> Geolocation => Invalid API key.
ERROR - 2016-03-08 23:34:26 --> Geolocation => Invalid API key.
