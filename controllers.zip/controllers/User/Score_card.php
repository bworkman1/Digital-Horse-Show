<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Score_card extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->_init();
    }

    private function _init()
    {
        $this->load->js('assets/themes/default/js/app/common.js');
        $this->load->js('assets/themes/default/js/jquery-scrolltofixed-min.js');

        $this->load->model('Security');
        $this->output->set_template('default');
    }

    public function index()
    {

    }

    public function my_score()
    {
        $id = (int)$this->uri->segment(4);

        $this->output->set_template('full-screen');

        $this->load->model('Coach/Grades');
        $this->load->model('user_videos');

        $data['video'] = $this->user_videos->getVideo($id);
        $data['scores'] = $this->Grades->getScoreCard($id);

        if(empty($data['scores'])) {
            $this->session->set_flashdata('error', 'No score card found for that video, try again');
            redirect('user/my-uploads');
            exit;
        }

        $this->load->view('score-cards/view-score-card', $data);
    }

}