<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Score_card extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->_init();
    }

    private function _init()
    {
        $this->load->js('assets/themes/default/js/app/common.js');
        $this->load->js('assets/themes/default/js/app/score-card.js');
        $this->load->js('assets/themes/default/js/jquery-scrolltofixed-min.js');

        $this->load->model('Security');
        $this->output->set_template('default');
    }

    public function index()
    {

    }

    public function view_score_card()
    {
        $id = (int)$this->uri->segment(4);

        $this->output->set_template('full-screen');

        $this->load->model('Coach/Grades');
        $this->load->model('user_videos');

        $data['video'] = $this->user_videos->getVideo($id);
        $data['scores'] = $this->Grades->getScoreCard($id);

        if(empty($data['scores'])) {
            $this->session->set_flashdata('error', 'No score card found for that video, try again');
            redirect('user/my-uploads');
            exit;
        }

        $this->load->view('score-cards/view-score-card', $data);

    }

    public function needs_scored()
    {
        $this->load->model('coach/Grades');
        $data['videos'] = $this->Grades->needsGraded($this->session->userdata('user_id'));

        $this->load->view('coach/needs-scored', $data);
    }

    public function sort()
    {
        $this->form_validation->set_rules('sort_by', 'Sort By', 'required|min_length[2]|max_length[15]');
        if ($this->form_validation->run() == true) {

            if(!array_key_exists ($_POST['sort_by'], $this->sortOptions)) {
                $this->session->set_flashdata('error', 'Invalid Sort By Selection!');
            } else {
                $this->session->set_flashdata('success', 'Videos are now sorted!');
                $this->session->set_userdata('video_sort', $_POST['sort_by']);
            }
        } else {
            $this->session->set_flashdata('error', validation_errors('<span>','</span>'));
        }

        redirect('coach/needs-scored');
        exit;
    }

    public function grade_ride()
    {
        $this->output->set_template('full-screen');
        $id = (int)$this->uri->segment(4);
        if($this->ion_auth->in_group('coach') && !empty($id)) {
            $this->load->model('user_videos');
            $data['video'] = $this->user_videos->getVideo($id);
            $this->user_videos->isVideoGraded($data['video']->id) == TRUE ? redirect('coach/score-card/view-score-card') : '';
            if($data['video']) {
                $this->load->view('score-cards/score-card', $data);
            } else {
                $this->session->set_flashdata('error', 'Video not found, try again');
                redirect($_SERVER['HTTP_REFERER']);
                exit;
            }
        } else {
            $this->session->set_flashdata('error', 'Only a coach is allowed to view that page');
            redirect('user/dashboard');
            exit;
        }
    }

    public function add_grade()
    {
        if($this->input->is_ajax_request()) {
            $this->output->unset_template();

            $this->load->model('coach/grades');

            $id = (int)$this->uri->segment(4);
            if($this->ion_auth->in_group('coach') && !empty($id) && $this->grades->isValidCoach($id)) {
                foreach($_POST as $key => $val) {
                    $columnName = ucwords(str_replace('_', ' ', $key));
                    if (strpos($key, 'remarks') !== false) {
                        $this->form_validation->set_rules($key, $columnName, 'max_length[249]xss_clean');
                    } else {
                        $this->form_validation->set_rules($key, $columnName, 'min_length[1]|max_length[3]|required|numeric');
                    }
                }
                if ($this->form_validation->run() == true) {
                    $feedback = $this->grades->submitGrade($_POST, $id);
                } else {
                    $feedback = array('error' => validation_errors());
                }
            } else {
                $feedback = array('error' => 'You are not authorized to grade this users ride, if this is an error please contact support');
            }

            echo json_encode($feedback);
        } else {
            $this->load->js('assets/themes/default/js/app/common.js');
            $this->load->js('assets/themes/default/js/app/error-404.js');
            $this->load->js('assets/themes/default/plugins/alertify/alertify.min.js');
            $this->load->css('assets/themes/default/css/error_404.css');
            $this->load->css('assets/themes/default/plugins/alertify/css/alertify.min.css');
            $this->load->view('404-page');
        }
    }

}