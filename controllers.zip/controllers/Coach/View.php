<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class View extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->_init();
    }

    private function _init()
    {
        $this->load->js('assets/themes/default/js/app/common.js');
        $this->load->js('assets/themes/default/js/jquery-scrolltofixed-min.js');

        $this->load->model('Security');
        $this->output->set_template('default');
    }



}