<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Coaches extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function getAvailableCoaches()
    {
        $result = $this->db->get_where('groups', array('name'=>'coach'));
        $coachRow = $result->row();
        $coaches = $this->ion_auth->users($coachRow->id)->result();
        return $coaches;
    }

    public function coachOptions()
    {
        $this->db->select('payments.coach_id, users.first_name, users.last_name, users.user_image');
        $this->db->join('users', 'users.id = payments.coach_id');
        $this->db->where('remaining >', 0);
        $this->db->where('user_id',  $this->session->userdata('user_id'));
        return $this->db->get('payments')->result();
    }

}