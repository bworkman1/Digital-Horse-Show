<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Grades extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function isValidCoach($id)
    {
        $result = $this->db->get_where('video_uploads', array('coach_id'=>$this->session->userdata('user_id'), 'id'=>$id));
        if($result->num_rows()>0){
            return true;
        }
        return false;
    }

    public function submitGrade($data, $video_id)
    {
        $fields = $this->db->list_fields('scoring');
        $videoData = $this->getVideoData($video_id);

        $error = false;
        foreach($data as $key => $val) {
            if(!in_array($key, $fields)) {
                $error = true;
            }
        }

        if(!$error) {
            $data['user_id'] = $videoData->user_id;
            $data['coach_id'] = $this->session->userdata('user_id');
            $data['video_id'] = $video_id;
            $this->db->insert('scoring', $data);
            if($this->db->insert_id()>0) {
                $this->setVideoStarRank($data['total'], $video_id);
                $feedback = array('success'=>'Score saved');
                $this->session->set_flashdata('success', 'Scores saved successfully');
            } else {
                $feedback = array('error'=>'Something went wrong saving the data, if this keeps happening contact support.');
            }

        } else {
            $feedback = array('error'=>'Invalid values found in the form, try refreshing your page and starting again');
        }

        return $feedback;
    }

    private function getVideoData($id)
    {
        $result = $this->db->get_where('video_uploads', array('id'=>$id));
        return $result->row();
    }

    private function setVideoStarRank($total, $id)
    {
        switch($total) {
            case $total>150:
                $stars = 5;
                break;
            case $total>120:
                $stars = 4;
                break;
            case $total>90:
                $stars = 3;
                break;
            case $total>60:
                $stars = 2;
                break;
            case $total>30:
                $stars = 1;
                break;
            default:
                $stars = 0;
        }
        $this->db->where('id', $id);
        $this->db->update('video_uploads', array('star_rating' => $stars));
    }

    public function getScoreCard($video_id)
    {
        if($this->ion_auth->in_group('coach')) {
            $this->db->where('coach_id', $this->session->userdata('user_id'));
        } else {
            $this->db->where('user_id', $this->session->userdata('user_id'));
        }
        $this->db->where('video_id', $video_id);
        $result = $this->db->get('scoring');
        return $result->row();
    }

    public function needsGraded($coach_id)
    {
        $this->db->order_by('id', 'desc');
        $result = $this->db->get_where('video_uploads', array('coach_id' => $coach_id, 'star_rating' => 0));
        return $result->result();
    }

}