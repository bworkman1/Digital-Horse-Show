<?php $this->load->view('ui-elements/ui-feedback'); ?>
<?php echo $data; ?>