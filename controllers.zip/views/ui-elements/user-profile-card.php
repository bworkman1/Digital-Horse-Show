<div class="well well-sm wow fadeInUp">
    <div class="row">
        <div class="col-sm-3">
            <img src="<?php echo base_url($video->user_image); ?>" class="img-responsive img-center">
        </div>
        <div class="col-md-9">
            <h3 class="text-info" style="margin-top: 0">Brian Workman</h3>
            <h6>Member Since <?php echo date('M d, Y', $video->created_on); ?></h6>
            <?php
                if($video->user_id == $this->session->userdata('user_id')) {
                    echo '<a href="'.base_url('user/my-profile/edit').'" class="btn btn-primary">Edit Profile</a>';
                } elseif($video->profile_public == 'yes') {
                    echo '<a href="'.base_url('user/my-profile/edit').'" class="btn btn-info">View Profile</a>';
                }
            ?>
        </div>
    </div>
</div>