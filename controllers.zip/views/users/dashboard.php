<div class="row">
    <div class="col-md-3">
        <div class="well well-sm well-colored">
            <h4>4 Credits Left</h4>
            <p>See More</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="well well-sm well-colored">
            <h4>5 Reviewed</h4>
            <p>See More</p>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4 col-md-6 col-lg-offset-4 col-md-offset-3">
        <div class="well well-sm">

            <?php $this->load->view('ui-elements/ui-feedback'); ?>
            <h3>Success You Have Been Logged In</h3>

        </div>
    </div>
</div>
