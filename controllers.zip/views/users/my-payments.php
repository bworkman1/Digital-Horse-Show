<div class="well well-sm">
    <h4 class="border-bottom"><i class="fa fa-clock-o"></i> My Purchase History</h4>
    <table class="table table-striped table-condensed">
        <thead style="font-weight: bold">
            <tr>
                <td>Trans Id</td>
                <td>Date</td>
                <td>Amount</td>
                <td>Coach</td>
                <td>Credits</td>
                <td>Remaining</td>
            </tr>
        </thead>
        <tbody>
            <?php
                $footer_totals = array(
                    'amount'    => 0,
                    'credits'   => 0,
                    'remaining' => 0,
                );
                foreach($payments as $payment) {
                    echo '<tr>';
                        echo '<td>'.$payment->trans_id.'</td>';
                        echo '<td>'.date('m-d-Y', strtotime($payment->paid_on)).'</td>';
                        echo '<td>$'.number_format($payment->amount, 2).'</td>';
                        echo '<td>'.$payment->first_name.' '.$payment->last_name.'</td>';
                        echo '<td>'.$payment->credits.'</td>';
                        echo '<td>'.$payment->remaining.'</td>';
                    echo '</tr>';

                    $footer_totals['amount'] = $footer_totals['amount']+$payment->amount;
                    $footer_totals['credits'] = $footer_totals['credits']+$payment->credits;
                    $footer_totals['remaining'] = $footer_totals['remaining']+$payment->remaining;
                }
            ?>
        </tbody>
        <tfooter style="font-weight: bold">
            <tr>
                <td colspan="2" class="text-right"><b>Total:</b></td>
                <td><?php echo '$'. number_format($footer_totals['amount'], 2); ?></td>
                <td></td>
                <td><?php echo $footer_totals['credits']; ?></td>
                <td><?php echo $footer_totals['remaining']; ?></td>
            </tr>
        </tfooter>
    </table>
    <a href="<?php echo base_url('user/payment'); ?>" class="btn btn-primary">Purchase More</a>
</div>




<div id="menu-page" data-page="<?php echo $page_name; ?>"></div>