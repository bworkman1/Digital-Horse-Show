<div class="page-title">
    <div class="row">
        <div class="col-lg-9 col-md-6">
            <h5><i class="fa fa-video-camera"></i> Upload Video File</h5>
        </div>
        <div class="col-lg-3 col-md-6">
            <?php $this->load->view('ui-elements/search-videos-form'); ?>
        </div>
    </div>
</div>

<?php if($user->coaching_credits>0) { ?>
    <?php echo form_open_multipart('user/upload-video/upload', array('id' => 'upload-form')); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="well well-sm wow fadeInUp" data-wow-delay="200ms">
                <div id="upload-heading"></div>
                <?php $this->load->view('ui-elements/ui-feedback'); ?>
                <h4 class="border-bottom">Upload Details</h4>
                <fieldset class="form-group">
                    <label><span class="text-danger">*</span> Video Name:</label>
                    <input id="video-name" name="name" type="text" value="" class="form-control input-md" required maxlength="100">
                </fieldset>

                <div class="row">
                    <div class="col-md-6">
                        <fieldset class="form-group">
                            <label><span class="text-danger">*</span> Competition Name:</label>
                            <input id="comp-name" name="comp_name" type="text" value="" class="form-control input-md" required maxlength="100">
                        </fieldset>
                    </div>
                    <div class="col-md-6">
                        <fieldset class="form-group">
                            <label><span class="text-danger">*</span> Class:</label>
                            <input id="comp-class" name="comp_class" type="text" value="" class="form-control input-md" required maxlength="100">
                        </fieldset>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <fieldset class="form-group">
                            <label><span class="text-danger">*</span> Competition Date:</label>
                            <input id="date-input" name="date" type="text" value="" class="form-control input-md datepicker" maxlength="100" required>
                        </fieldset>
                    </div>
                    <div class="col-md-6">
                        <fieldset class="form-group">
                            <label><span class="text-danger">*</span> Name and Number of Horse:</label>
                            <input id="horse-name" name="horse_name" type="text" value="" class="form-control input-md" maxlength="100" required>
                        </fieldset>
                    </div>
                </div>

                <fieldset class="form-group">
                    <label>Video Location:</label>
                    <input id="pac-input" name="location" type="text" value="" class="form-control input-md" maxlength="100">
                </fieldset>

                <fieldset class="form-group">
                    <label><span class="text-danger">*</span> Add Video File:</label>
                    <input type="file" class="form-control" id="file" name="file">
                </fieldset>

                <fieldset class="form-group">
                    <?php if(count($coaches)>1) { ?>
                        <label><span class="text-danger">*</span> Select Coach:</label>
                        <select name="coach" class="form-control">
                            <?php
                                foreach($coaches as $coach) {
                                    echo '<option value="'.$coach->coach_id.'">'.ucwords($coach->first_name).' '.ucwords($coach->last_name).'</option>';
                                }
                            ?>
                        </select>
                    <?php } else {
                        echo '<div class="alert alert-info"><img src="'.base_url($coaches[0]->user_image).'" height="50" width="50" class="img-circle pull-left"><h5 style="color: #ffffff; margin: 0">'.ucwords($coaches[0]->first_name).' '.ucwords($coaches[0]->last_name).' will be your coach</h5><p style="color: #ffffff">Once your upload completes he will be notified to judge your ride.</p></div>';
                        echo '<input type="hidden" name="coach" value="'.$coaches[0]->coach_id.'" required>';
                     } ?>
                </fieldset>



                <div id="feedback"></div>

                <div class="progress hide">
                    <div class="progress-bar progress-bar-striped active" role="progressbar"
                         aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width:0%">
                        40%
                    </div>
                </div>

                <input type="hidden" id="locLat" name="lat">
                <input type="hidden" id="locLng" name="lng">
                <br>
                <button type="submit" id="submit" class="btn btn-primary"><i class="fa fa-upload"></i> Start Upload</button>

            </div>
        </div>

        <div class="col-md-6">
            <?php echo '<div class="alert alert-info" style="font-size: 1.3em;  font-weight: bold;"><i class="fa fa-question-circle"></i> You have '.$user->coaching_credits.' coaching credits left.</div>'; ?>
            <div class="well well-sm wow fadeInUp" data-wow-delay="400ms">
                <div id="map" style="height: 400px; width: 100%"></div>
            </div>
        </div>

    </div>

    <?php echo form_close(); ?>
<?php } else { ?>

    <div class="panel panel-info">
        <div class="panel-heading">
            <h5 style="color: #ffffff">Oh No! You Need Coaching Credits!</h5>
        </div>
        <div class="panel-body">
            <p>No worries, head over to the payment page and select the coach you would like and enter your payment info and <b>BAM!</b> You're back in business.</p><p>This is where you will want to sell it to the user on why to buy credits and all the benefits.</p>
            <a href="<?php echo base_url('user/payment'); ?>" class="btn btn-primary">Purchase Credits</a>
        </div>
    </div>




<?php } ?>

<div id="menu-page" data-page="<?php echo $page_name; ?>"></div>
<div id="user-lat" data-lat="<?php echo $this->session->userdata('lat'); ?>"></div>
<div id="user-lng" data-lng="<?php echo $this->session->userdata('lng'); ?>"></div>

<div id="upsale" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h4 class="modal-title text-success">Special Offer!</h4>
            </div>
            <div class="modal-body">
                <p>Would you like to have your scored/reviewed by one of our professional coaches?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default noUpsale" data-dismiss="modal">No</button>
                <button type="button" class="btn btn-success yesUpsale">Yes</button>
            </div>
        </div>
    </div>
</div>

<div id="payment" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <div class="panel panel-default credit-card-box">
                    <div class="panel-heading display-table" >
                        <div class="row display-tr" >
                            <h3 class="panel-title display-td" >Payment Details</h3>
                            <div class="display-td" >
                                <img class="img-responsive pull-right" src="<?php echo base_url('assets/themes/default/images/credit-cards.png'); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <form role="form" id="payment-form">
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="form-group">
                                        <label for="cardNumber">CARD NUMBER</label>
                                        <div class="input-group">
                                            <input
                                                type="tel"
                                                class="form-control"
                                                name="cardNumber"
                                                placeholder="Valid Card Number"
                                                autocomplete="cc-number"
                                                required autofocus
                                            />
                                            <span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-7 col-md-7">
                                    <div class="form-group">
                                        <label for="cardExpiry"><span class="hidden-xs">EXPIRATION</span><span class="visible-xs-inline">EXP</span> DATE</label>
                                        <input
                                            type="tel"
                                            class="form-control"
                                            name="cardExpiry"
                                            placeholder="MM / YY"
                                            autocomplete="cc-exp"
                                            required
                                        />
                                    </div>
                                </div>
                                <div class="col-xs-5 col-md-5 pull-right">
                                    <div class="form-group">
                                        <label for="cardCVC">CV CODE</label>
                                        <input
                                            type="tel"
                                            class="form-control"
                                            name="cardCVC"
                                            placeholder="CVC"
                                            autocomplete="cc-csc"
                                            required
                                        />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="form-group">
                                        <label for="couponCode">COUPON CODE</label>
                                        <input type="text" class="form-control" name="couponCode" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12">
                                    <button class="btn btn-success btn-lg btn-block" type="submit">Submit Payment</button>
                                </div>
                            </div>
                            <div class="row" style="display:none;">
                                <div class="col-xs-12">
                                    <p class="payment-errors"></p>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default noUpsale" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>