<img src="<?php echo base_url('assets/themes/default/images/404-page-horse.jpg'); ?>" class="bg">

<div class="row">
    <div class="col-md-6 col-md-offset-3">
        <div class="well well-sm">
            <h3 class="text-info">Looking for a User?</h3>
            <hr>
            <div class="right-inner-addon ">
                <i class="fa fa-search"></i>
                <input id="search-box" type="text" class="form-control" placeholder="Search" maxlength="20">
            </div>
            <div class="helper text-muted"></div>
            <br>

            <div id="results"></div>

        </div>
    </div>
</div>