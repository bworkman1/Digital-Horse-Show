<footer class="footer">
    <div class="container text-center">
        Copyright &copy; Digital Horse Show |
        <a href="<?php echo base_url('privacy-policy'); ?>">Privacy Policy</a> |
        <a href="<?php echo base_url('terms-of-service'); ?>">Terms of Service</a>
    </div>
</footer>

