<h5 class="page-title"><i class="fa fa-list"></i> Score Card</h5>
<div class="row scrollContain">
    <div class="col-lg-4">

        <div class="well well-sm videoSide">
            <div class="embed-responsive embed-responsive-16by9">
                <video id="userVideo" controls="controls" poster="<?php echo base_url($video->thumb); ?>" width="640" height="360">
                    <source src="<?php echo base_url($video->path); ?>" type="<?php echo $video->file_type; ?>" />
                    <object type="application/x-shockwave-flash" data="http://releases.flowplayer.org/swf/flowplayer-3.2.1.swf" width="640" height="360">
                        <param name="movie" value="http://releases.flowplayer.org/swf/flowplayer-3.2.1.swf" />
                        <param name="allowFullScreen" value="true" />
                        <param name="wmode" value="transparent" />
                        <param name="flashVars" value="config={'playlist':['<?php echo base_url($video->thumb); ?>',{'url':'<?php echo base_url($video->path); ?>','autoPlay':false}]}" />
                        <img alt="<?php echo $video->orig_name; ?>" src="<?php echo base_url($video->thumb); ?>" width="640" height="360" title="No video playback capabilities, please download the video below" />
                    </object>
                </video>
            </div>
            <br>
            <?php $this->load->view('ui-elements/user-profile-card'); ?>
        </div>

    </div>
    <div class="col-lg-8">
        <?php echo form_open('coach/score-card/add-grade/'.$this->uri->segment(4), array('id'=>'scoreCard')); ?>
            <div class="well well-sm">
                <legend><i class="fa fa-user"></i> Rider Details</legend>
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <fieldset class="form-group">
                            <b>Name of Competition</b>
                            <input id="comp-name" type="text" readonly value="<?php echo $video->comp_name; ?>" class="form-control input-md" tabindex="1" maxlength="80">
                        </fieldset>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <fieldset class="form-group">
                            <b>Class</b>
                            <input id="class" type="text" readonly  value="<?php echo $video->comp_class; ?>" class="form-control input-md" tabindex="2" maxlength="80">
                        </fieldset>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <fieldset class="form-group">
                            <b>Date</b>
                            <input id="comp-date" type="text" readonly class="form-control input-md" value="<?php echo date('d-m-Y', strtotime($video->date)); ?>" tabindex="3" maxlength="80">
                        </fieldset>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <fieldset class="form-group">
                            <b>Number and Name of Horse</b>
                            <input id="comp-horse" type="text" readonly value="<?php echo $video->horse_name; ?>" class="form-control input-md" tabindex="4" maxlength="80">
                        </fieldset>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <fieldset class="form-group">
                            <b>Name of Rider</b>
                            <input id="rider-name" type="text" readonly value="<?php echo $video->first_name.' '.$video->last_name; ?>" readonly class="form-control input-md" tabindex="5" maxlength="80">
                        </fieldset>
                    </div>


                </div>
                <hr>

                <button id="scoringHelp" class="btn btn-success pull-right" data-target="#score-help" data-toggle="modal">Scoring Instructions</button>
                <legend><i class="fa fa-bullseye"></i> Rider Scoring</legend>
                <div class="clearfix"></div>
                <div class="table-responsive">
                    <table id="scoreCard" class="table table-bordered table-hover table-condensed">
                        <thead>
                            <tr>
                                <td></td>
                                <td>Test</td>
                                <td>Directive Ideas</td>
                                <td class="text-center">Points</td>
                                <td class="text-center">Coefficent</td>
                                <td class="text-center">Total</td>
                                <td>Remarks</td>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td><b>1. A</b><br>Between <b>X & C</b></td>
                                <td>Track right. <br>Working trot rising.</td>
                                <td>Balance and bend in turn. Quality of transition.</td>
                                <td>
                                    <input type="text" name="score_1_points" class="form-control score-box nums-only" tabindex="7" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_1_co" class="form-control score-box nums-only" tabindex="8" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_1" tabindex="9"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td><b>2. C M</b></td>
                                <td>Enter working trot raising.<b>Medium walk</b></td>
                                <td>Straightness on centerline and in transition: clear trot and walk rhythm.</td>
                                <td>
                                    <input type="text" name="score_2_points" class="form-control score-box nums-only" tabindex="10" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_2_co" class="form-control score-box nums-only" tabindex="11" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_2" tabindex="12"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td><b>3. A</b></td>
                                <td>Circle right 20 meters, working trot rising.</td>
                                <td>Roundness and size of circle; clear trot rhythm and bend.</td>
                                <td>
                                    <input type="text" name="score_3_points" class="form-control score-box nums-only" tabindex="13" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_3_co" class="form-control score-box nums-only" tabindex="14" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_3" tabindex="15"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td><b>4. K-X-M</b></td>
                                <td>Change rein.</td>
                                <td>Clear trot rhythm and straightness on diagonal; bend through corners.</td>
                                <td>
                                    <input type="text" name="score_4_points" class="form-control score-box nums-only" tabindex="16" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_4_co" class="form-control score-box nums-only" tabindex="17" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_4" tabindex="18"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td><b>5. C</b></td>
                                <td>Circle left 20 meters, working trot rising.</td>
                                <td>Roundness and size of circle clear trot rhythm and bend.</td>
                                <td>
                                    <input type="text" name="score_5_points" class="form-control score-box nums-only" tabindex="19" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_5_co" class="form-control score-box nums-only" tabindex="20" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_5" tabindex="21"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td><b>6. Between C & H</b></td>
                                <td>Medium walk.</td>
                                <td>Willing and balanced transition; clear walk rhythm.</td>
                                <td>
                                    <input type="text" name="score_6_points" class="form-control score-box nums-only" tabindex="22" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_6_co" class="form-control score-box nums-only" tabindex="23" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_6" tabindex="24"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td><b>7. H-X-F</b></td>
                                <td>Free walk.</td>
                                <td>Complete freedom to stretch neck forward and downward; clear walk rhythm, straightness on the diagonal; ground cover.</td>
                                <td>
                                    <input type="text" name="score_7_points" class="form-control score-box nums-only" tabindex="25" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_7_co" class="form-control score-box nums-only" tabindex="26" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_7" tabindex="27"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td><b>8. F-A <br>A</b></td>
                                <td>Medium walk.<br>Down centerline</td>
                                <td>Willing and balanced transition; clear walk rhythm, bending in corner and turn.<br>
                                    Straightness on centerline.</td>
                                <td>
                                    <input type="text" name="score_8_points" class="form-control score-box nums-only" tabindex="28" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_8_co" class="form-control score-box nums-only" tabindex="29" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_8" tabindex="30"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td><b>9. X</b></td>
                                <td>Halt and salute.</td>
                                <td>Straightness; willing, balanced transition at halt.</td>
                                <td>
                                    <input type="text" name="score_9_points" class="form-control score-box nums-only" tabindex="31" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_9_co" class="form-control score-box nums-only" tabindex="32" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_9" tabindex="33"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="7"><h6><b>Collective Marks</b></h6></td>
                            </tr>

                            <tr>
                                <td colspan="3">Gaits (freedom and regularity).</td>
                                <td>
                                    <input type="text" name="score_10_points" class="form-control score-box nums-only" tabindex="34" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_10_co" class="form-control score-box nums-only" tabindex="35" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_10" tabindex="36"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="3">Impulsion (desire to move forward with suppleness of the back and steady tempo).</td>
                                <td>
                                    <input type="text" name="score_11_points" class="form-control score-box nums-only" tabindex="37" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_11_co" class="form-control score-box nums-only" tabindex="38" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_11" tabindex="39"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="3">Submission (acceptance of steady contact, attention, and confidence).</td>
                                <td>
                                    <input type="text" name="score_12_points" class="form-control score-box nums-only" tabindex="40" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_12_co" class="form-control score-box nums-only" tabindex="41" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_12" tabindex="42"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="3">Rider’s position (keeping in balance with horse).</td>
                                <td>
                                    <input type="text" name="score_13_points" class="form-control score-box nums-only" tabindex="43" maxlength="2" required value="0">
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_13_co" class="form-control score-box nums-only" tabindex="44" maxlength="2" required value="0">
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_13" tabindex="45"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="3">Rider’s effectiveness of aids (correct bend and preparation of transitions).</td>
                                <td>
                                    <input type="text" name="score_14_points" class="form-control score-box nums-only" tabindex="46" required maxlength="2" value="0">
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_14_co" class="form-control score-box nums-only" tabindex="47" required maxlength="2" value="0">
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_14" tabindex="48"></textarea>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="3">Geometry and accuracy (correct size and shape of circles and turns).</td>
                                <td>
                                    <input type="text" name="score_15_points" class="form-control score-box nums-only" tabindex="49" maxlength="2" value="0" required>
                                </td>
                                <td valign="bottom">
                                    <input type="text" name="score_15_co" class="form-control score-box nums-only" tabindex="50" maxlength="2" value="0" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control total" readonly value="0">
                                </td>
                                <td>
                                    <textarea maxlength="254" name="remarks_15" tabindex="51"></textarea>
                                </td>
                            </tr>

                        </tbody>

                        <tfoot>
                            <tr>
                                <td colspan="4" class="score-feedback"></td>
                                <td class="text-right"><b>Sub Total:</b></td>
                                <td><div id="sub-total" class="text-center">0</div></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">Leave arena in free walk. Exit at A.</td>
                                <td class="text-right"><b>Errors:</b></td>
                                <td><input type="text" name="errors" class="form-control scoreError nums-only" value="0" tabindex="52"></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4" id="ajax-feedback"></td>
                                <td class="text-right"><b>Total:</b></td>
                                <td><input type="text" class="form-control grandTotal" readonly></td>
                                <td></td>
                            </tr>
                        </tfoot>

                    </table>
                </div>
                <input type="hidden" id="totalScore" name="total" maxlength="3" required>
                <button type="submit" id="scoreSubmit" class="btn btn-primary pull-right" tabindex="53">Submit Score</button>
                <div class="clearfix"></div>
            </div>
        <?php echo form_close(); ?>
    </div>
</div>




<div id="score-help" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><i class="fa fa-bullseye"></i> Scoring Instructions</h4>
            </div>
            <div class="modal-body">
                <p>This unique series of tests provides an opportunity for the horse and/or rider new to dressage to demonstrate elementary skills.
                    The tests have been designed to encourage correct performance and to prepare the horse for the transition to the USEF tests.</p>
                <div class="row">
                    <div class="col-md-6">
                        <h5>INSTRUCTION:</h5>
                        <p>All trot work to be ridden rising. Transitions from walk to trot and trot to walk may be
                            performed through sitting trot with the objective of performing a smooth transition.</p>
                        <p>Turns from center line to long side and long side to
                            center line should be ridden as a half circle, touching
                            the track at a point midway between the center line
                            and the corner, and vice versa.</p>
                    </div>
                    <div class="col-md-6">
                        <h5>COMMENT:</h5>
                        <p>Horses should be ridden on a light but steady contact,
                            with the exception of the free walk in which the horse is
                            allowed complete freedom to stretch neck forward and
                            downward.</p>
                    </div>
                </div>
                <hr>
                <img src="<?php echo base_url('assets/themes/default/images/scoring-image.png'); ?>" class="img-responsive img-center">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>