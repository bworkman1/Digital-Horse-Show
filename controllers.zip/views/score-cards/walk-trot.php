<div class="table-responsive">
    <table class="table table-condensed">

        <thead>
            <tr>
                <td></td>
                <td>Test</td>
                <td>Directive Ideas</td>
                <td>Points</td>
                <td>Coefficient</td>
                <td>Total</td>
                <td>Remarks</td>
            </tr>
        </thead>

        <tbody>
            <tr>
                <td>
                    1. A Between X&C
                </td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </tbody>

    </table>


</div>